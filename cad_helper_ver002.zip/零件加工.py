from stp_generator import *
THREAD_SIZE_ITEMS = {
    "M2": {"major_d": 2.0, "minor_d": 1.57, "pitch": 0.4},
    "M2.5": {"major_d": 2.5, "minor_d": 2.01, "pitch": 0.45},
    "M3": {"major_d": 3.0, "minor_d": 2.46, "pitch": 0.5},
    "M3.5": {"major_d": 3.5, "minor_d": 2.85, "pitch": 0.6},
    "M4": {"major_d": 4.0, "minor_d": 3.24, "pitch": 0.7},
    "M5": {"major_d": 5.0, "minor_d": 4.13, "pitch": 0.8},
    "M6": {"major_d": 6.0, "minor_d": 4.92, "pitch": 1.0},
    "M7": {"major_d": 7.0, "minor_d": 5.92, "pitch": 1.0},
    "M8": {"major_d": 8.0, "minor_d": 6.65, "pitch": 1.25},
    "M10": {"major_d": 10.0, "minor_d": 8.38, "pitch": 1.5},
    "M12": {"major_d": 12.0, "minor_d": 10.11, "pitch": 1.75},
    "M14": {"major_d": 14.0, "minor_d": 11.83, "pitch": 2.0},
    "M16": {"major_d": 16.0, "minor_d": 13.83, "pitch": 2.0},
    "M18": {"major_d": 18.0, "minor_d": 15.29, "pitch": 2.5},
}

part_name = "./stp_files/part3b"
svg_save_name = f"{part_name}.svg"
stp_save_name = f"{part_name}.stp"

part = cq.Workplane("XY").box(100, 30, 20, centered=(False, False, False))

def add_thread(model, xyz, dir_x, dir_n, cbor={"直徑":4, "深":1}, thread={"牙型":"M3", "牙深":6, "預留鑽深":1, "尖錐":True}):
    n = cq.Vector(dir_n).normalized()
    p = cq.Vector(xyz)
    thead_size = THREAD_SIZE_ITEMS[thread["牙型"]]["minor_d"] / 2
    if cbor is not None :
        plane = cq.Plane(origin=p.toTuple(), xDir=dir_x, normal=dir_n)
        cutter = ( cq.Workplane(plane).circle(cbor["直徑"]/2).extrude(-cbor["深"]) )
        model = model.cut(cutter, clean=False)
        p = p - n.multiply(cbor["深"])
    plane = cq.Plane(origin=p.toTuple(), xDir=dir_x, normal=dir_n)
    cutter = ( cq.Workplane(plane).circle(thead_size).extrude(-thread["牙深"]) )
    model = model.cut(cutter, clean=False)
    p = p - n.multiply(thread["牙深"])
    plane = cq.Plane(origin=p.toTuple(), xDir=dir_x, normal=dir_n)
    cutter = ( cq.Workplane(plane).circle(thead_size).extrude(-thread["預留鑽深"]) )
    p = p - n.multiply(thread["預留鑽深"])
    if thread["尖錐"] :
        cone_h = thead_size / math.tan(math.radians(60))
        cone_solid = cq.Solid.makeCone(radius1=thead_size, radius2=0., height=cone_h, pnt=p+n.multiply(0.00001), dir=n.multiply(-1))
        cutter = cutter.union(cq.Workplane().add(cone_solid), clean=True)
    model = model.cut(cutter, clean=False)
    return model
def add_hole(model, xyz, dir_x, dir_n, cbor={"直徑":4, "深":1}, hole={"直徑":2, "深":4, "尖錐":True}):
    n = cq.Vector(dir_n).normalized()
    p = cq.Vector(xyz)
    if cbor is not None :
        plane = cq.Plane(origin=p.toTuple(), xDir=dir_x, normal=dir_n)
        cutter = ( cq.Workplane(plane).circle(cbor["直徑"]/2).extrude(-cbor["深"]) )
        model = model.cut(cutter, clean=False)
        p = p - n.multiply(cbor["深"])
    hole_r = hole["直徑"]/2
    plane = cq.Plane(origin=p.toTuple(), xDir=dir_x, normal=dir_n)
    cutter = ( cq.Workplane(plane).circle(hole_r).extrude(-hole["深"]) )
    p = p - n.multiply(hole["深"])
    if hole["尖錐"] :
        cone_h = hole_r / math.tan(math.radians(60))
        cone_solid = cq.Solid.makeCone(radius1=hole_r, radius2=0., height=cone_h, pnt=p+n.multiply(0.00001), dir=n.multiply(-1))
        cutter = cutter.union(cq.Workplane().add(cone_solid), clean=True)
    model = model.cut(cutter, clean=False)
    return model



x_now = 10
pts = [(0,0),(0,8), (3,0)]
plane = cq.Plane(origin=(0, 0, 22), xDir=(1, 0, 0),  normal=(0, 0, 1), )
cutter = ( cq.Workplane(plane).polyline(pts).close().extrude(-30) )
part = part.cut(cutter, clean=False)


pts = [(0,0),(0,-3), (-3,0)]
plane = cq.Plane(origin=(100, 30, 22), xDir=(1, 0, 0),  normal=(0, 0, 1), )
cutter = ( cq.Workplane(plane).polyline(pts).close().extrude(-30) )
part = part.cut(cutter, clean=False)

pts = [(0,0),(0,3), (-3,0)]
plane = cq.Plane(origin=(100, 0, 22), xDir=(1, 0, 0),  normal=(0, 0, 1), )
cutter = ( cq.Workplane(plane).polyline(pts).close().extrude(-30) )
part = part.cut(cutter, clean=False)

plane = cq.Plane(origin=(50,14,21), xDir=(1, 0, 0),  normal=(0, 0, 1), )
cutter = ( cq.Workplane(plane).circle(2).extrude(-30) )
part = part.cut(cutter, clean=False)

plane = cq.Plane(origin=(55,14,21), xDir=(1, 0, 0),  normal=(0, 0, 1), )
cutter = ( cq.Workplane(plane).rect(10,10).extrude(-30) )
part = part.cut(cutter, clean=False)


plane = cq.Plane(origin=(70,14,21), xDir=(1, 0, 0),  normal=(0, 0, 1), )
cutter = ( cq.Workplane(plane).circle(6).extrude(-30) )
part = part.cut(cutter, clean=False)

plane = cq.Plane(origin=(70,6,21), xDir=(1, 0, 0),  normal=(0, 0, 1), )
cutter = ( cq.Workplane(plane).rect(4,8).extrude(-30) )
part = part.cut(cutter, clean=False)

part = part.edges(cq.NearestToPointSelector((66, 2, 10))).fillet(2)


















part = add_thread(part, (10,10,20), (1,0,0), (0,0,1), cbor={"直徑":4, "深":1}, thread={"牙型":"M3", "牙深":6, "預留鑽深":1, "尖錐":True})

cbor={"直徑":4, "深":1}
hole={"直徑":2, "深":4, "尖錐":True}


plane = cq.Plane(origin=(30,15,20), xDir=(1, 0, 0),  normal=(0, 0, 1), )
cutter = ( cq.Workplane(plane).circle(8).extrude(2) )
part = part.union(cutter, clean=False)

eta = 5
dxy_set = [[0, eta], [0, -eta], [eta, 0], [-eta, 0]]
for dxy in dxy_set : 
    dxy[0] +=30
    dxy[1] +=15
    part = add_hole(part, (*tuple(dxy), 22), (1,0,0), (0,0,1), cbor=cbor, hole=hole)







view_dirs = [(-1.75, 1.1, 0), (1.75, -1.1, -5)]
imgs = model2img(part, svg_save_name, view_dirs=view_dirs)
img = Imgtool(imgs[0]).concat(imgs[1], axis=1).get()
cq.exporters.export(part, stp_save_name, exportType="STEP", opt={"write_pcurves": False})
