import os
import re
import sys
import math
import copy
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.append(os.path.join(ROOT_DIR, "toolbox"))
from common_functions import *
import numpy as np
import cadquery as cq
from cadquery import importers, Compound
from cadquery.occ_impl.exporters.dxf import DxfDocument
from ezdxf import bbox
from ezdxf.addons.importer import Importer
from ezdxf.math import Vec2, Matrix44
from ezdxf.addons.drawing import RenderContext, Frontend, layout, svg
from ezdxf.addons.drawing.config import Configuration, LinePolicy, LineweightPolicy
from ezdxf.addons.drawing.properties import LayoutProperties
import fitz
import datetime
from OCP.gp import gp_Pnt, gp_Dir, gp_Vec, gp_Ax2
from OCP.BRepLib import BRepLib
from OCP.BRepClass import BRepClass_FaceClassifier
from OCP.HLRAlgo import HLRAlgo_Projector
from OCP.HLRBRep import HLRBRep_Algo, HLRBRep_HLRToShape
from OCP.TopAbs import TopAbs_IN, TopAbs_ON
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox, BRepPrimAPI_MakeCylinder, BRepPrimAPI_MakeCone
from OCP.BRepAlgoAPI import BRepAlgoAPI_Cut, BRepAlgoAPI_Fuse
from OCP.BRepFilletAPI import BRepFilletAPI_MakeFillet, BRepFilletAPI_MakeChamfer


THREAD_SIZE_ITEMS = {
    "M2": {"major_d": 2.0, "minor_d": 1.57, "pitch": 0.4},
    "M2.5": {"major_d": 2.5, "minor_d": 2.01, "pitch": 0.45},
    "M3": {"major_d": 3.0, "minor_d": 2.46, "pitch": 0.5},
    "M3.5": {"major_d": 3.5, "minor_d": 2.85, "pitch": 0.6},
    "M4": {"major_d": 4.0, "minor_d": 3.24, "pitch": 0.7},
    "M5": {"major_d": 5.0, "minor_d": 4.13, "pitch": 0.8},
    "M6": {"major_d": 6.0, "minor_d": 4.92, "pitch": 1.0},
    "M7": {"major_d": 7.0, "minor_d": 5.92, "pitch": 1.0},
    "M8": {"major_d": 8.0, "minor_d": 6.65, "pitch": 1.25},
    "M10": {"major_d": 10.0, "minor_d": 8.38, "pitch": 1.5},
    "M12": {"major_d": 12.0, "minor_d": 10.11, "pitch": 1.75},
    "M14": {"major_d": 14.0, "minor_d": 11.83, "pitch": 2.0},
    "M16": {"major_d": 16.0, "minor_d": 13.83, "pitch": 2.0},
    "M18": {"major_d": 18.0, "minor_d": 15.29, "pitch": 2.5},
}
CAD_HELPER_HYP = {
    "視圖間隔": 80,
    "等角圖縮放": 1.0,
    "標準箭頭大小": 3.0,
    "標準字體高度": 3,
    "尺寸排間隔": 8,
    "尺寸排起始間隔": 20,
    "A3圖紙可用空間": [280, 200],
    "尺寸靠邊權重": {"front": {"x": 0.5, "y": 0.5}, "right": {"x": 0.5, "y": 0.5}, "left": {"x": 0.5, "y": 0.5}, "top": {"x": 0.5, "y": 0.5}, "bottom": {"x": 0.5, "y": 0.5}, "back": {"x": 0.5, "y": 0.5}},
    "孔編號起始字母": "D",
    "孔編號模式開關": True,
    "螺紋孔繪製角度": {"start": 255, "end": 165},
    "座標標注推擠權重": 2.4,
    "佔領圖紙權重": {"w": 1.5, "h": 1.5},
    "標注基準參考": {"front": "left-bottom", "right": "right-bottom", "left": "left-bottom", "top": "left-up", "bottom": "left-bottom", "back": "left-bottom"},
    "特殊標住基準參考": {"front": None, "right": None, "left": None, "top": None, "bottom": None, "back": None},
    "線性標注方法": {"front": "ordinate", "right": "linear", "left": "linear", "top": "linear", "bottom": "linear", "back": "linear"},
    "繪圖比例選項": ["1/20", "1/15", "1/10", "1/8", "1/5", "1/3", "1/2", "2/3", "3/4", "1/1", "4/3", "3/2", "2/1", "3/1", "4/1", "5/1", "8/1", "10/1", "15/1", "20/1"],
    "視圖佈局網格": {"iso_front": (3, 1), "top": (1, 2), "iso_back": (3, 0), "left": (0, 1), "front": (1, 1), "right": (2, 1), "bottom": (1, 0)},
    "隱藏線可見": {"front": True, "right": True, "left": True, "top": True, "bottom": True, "back": True},
    "孔標註排版": {"編號偏移": 0.6, "列間距": 2, "單行列高": 1.5, "雙行列高": 3},
    "線型比例": {"cen": {"gamma": 0.08, "beta": 1.0}, "hid": {"gamma": 0.25, "beta": 1.0}},
    "圓弧中心線角度門檻": 165,
    "滑槽偵測": {"啟用": True, "限正交方向": True},
    "板金模式": {"啟用": False, "板厚": None, "厚度容差": 0.05},
    "剖面圖": {"顯示隱藏線": True, "放置方式": "next_free", "填充線": {"啟用": True, "圖層": "HAT", "樣式": "ANSI31", "角度": 0, "比例": 1.0, "最小面積": 1e-6}},
}
DXF_COLOR_MAP = {
    "依圖塊": 0, "紅": 1, "黃": 2, "綠": 3, "青": 4, "藍": 5, "紫紅": 6,
    "洋紅": 6, "粉": 6, "白": 7, "黑": 7, "深灰": 8, "淺灰": 9, "橘色": 30, "依圖層": 256,}
DXF_LAYER_ITEMS = {
    "0": {"color": DXF_COLOR_MAP["白"], "linetype": "CONTINUOUS", "lineweight": 18},
    "HID": {"color": DXF_COLOR_MAP["綠"], "linetype": "HIDDEN", "lineweight": 18},
    "SUP": {"color": DXF_COLOR_MAP["橘色"], "linetype": "CONTINUOUS", "lineweight": 18},
    "AUTO_CEN": {"color": DXF_COLOR_MAP["紅"], "linetype": "AUTO_CENTER", "lineweight": 18},
    "DIM": {"color": DXF_COLOR_MAP["黃"], "linetype": "CONTINUOUS", "lineweight": 18},
    "AUTO_DIM": {"color": DXF_COLOR_MAP["黃"], "linetype": "CONTINUOUS", "lineweight": 18},
    "AUTO_DIM_HOLES": {"color": DXF_COLOR_MAP["紫紅"], "linetype": "CONTINUOUS", "lineweight": 18},
    "HAT": {"color": DXF_COLOR_MAP["青"], "linetype": "CONTINUOUS", "lineweight": 18},
    "cutted_0": {"color": DXF_COLOR_MAP["洋紅"], "linetype": "CONTINUOUS", "lineweight": 18},
    "TAN": {"color": DXF_COLOR_MAP["青"], "linetype": "CONTINUOUS", "lineweight": 18},
    "DEBUG1": {"color": DXF_COLOR_MAP["淺灰"], "linetype": "CONTINUOUS", "lineweight": 18},
    "DEBUG2": {"color": DXF_COLOR_MAP["粉"], "linetype": "CONTINUOUS", "lineweight": 18},
    "DEBUG3": {"color": DXF_COLOR_MAP["紫紅"], "linetype": "CONTINUOUS", "lineweight": 18},
}
DXF_LINETYPE_ITEMS = {
    "HIDDEN": {"pattern": [4, 3, -1], "description": "Hidden __ __ __ __ __ __ __"},
    "AUTO_CENTER": {"pattern": [12.5, 5, -1, 0.5, -1, 5], "description": "Auto center ____ . ____ . ____"},
}
VIEW_DIRECTION = {
    "front": {"N": (0, 0, 1), "U": (0, 1, 0), "label": "FRONT"},
    "right": {"N": (1, 0, 0), "U": (0, 1, 0), "label": "RIGHT"},
    "top": {"N": (0, 1, 0), "U": (0, 0, -1), "label": "TOP"},
    "back": {"N": (0, 0, -1), "U": (0, 1, 0), "label": "BACK"},
    "left": {"N": (-1, 0, 0), "U": (0, 1, 0), "label": "LEFT"},
    "bottom": {"N": (0, -1, 0), "U": (0, 0, 1), "label": "BOTTOM"},
    "iso_front": {"N": (1, 1, 1), "U": (0, 1, 0), "label": "ISO FRONT"},
    "iso_back": {"N": (-1, -1, -1), "U": (0, 1, 0), "label": "ISO BACK"},
}
def get_nums(text):
    return [float(x) for x in re.findall(r"[-+]?\d*\.?\d+(?:[Ee][-+]?\d+)?", text)]
def cal_collinear(v1, v2, eta=1e-2):
    v1 = np.array(v1, dtype=float)
    v2 = np.array(v2, dtype=float)
    v1_len = np.linalg.norm(v1)
    v2_len = np.linalg.norm(v2)
    if v1_len == 0 or v2_len == 0: return None
    dot = float(np.dot(v1 / v1_len, v2 / v2_len))
    if dot > 1 - eta: return "postive"
    if dot < -1 + eta: return "negative"
    return None
def scale_cjk_text(text):
    text = str(text)
    return re.sub(r"[\u4e00-\u9fff]+", lambda m: "\\H1.2x;" + m.group(0) + "\\H0.833333x;", text)
def model2img(model, svg_save_name=None, width=1200, height=800, view_dirs=None):
    shape = model.val() if isinstance(model, cq.Workplane) else model
    multi_view = view_dirs is not None
    if view_dirs is None: view_dirs = [None]
    imgs = []
    for view_idx, view_dir in enumerate(view_dirs):
        svg_options = {"width":width, "height":height, "showAxes":False}
        if view_dir is not None: svg_options["projectionDir"] = view_dir
        svg_text = cq.exporters.getSVG(shape, svg_options)
        if svg_save_name is not None:
            if not svg_save_name.lower().endswith(".svg"): svg_save_name = f"{svg_save_name}.svg"
            this_svg_save_name = svg_save_name
            if multi_view:
                svg_name, svg_ext = os.path.splitext(svg_save_name)
                this_svg_save_name = f"{svg_name}_view{view_idx + 1}{svg_ext}"
            create_folder(this_svg_save_name)
            with open(this_svg_save_name, "w", encoding="utf-8") as f: f.write(svg_text)
        doc = fitz.open(stream=svg_text.encode("utf-8"), filetype="svg")
        pix = doc[0].get_pixmap(alpha=False)
        img = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width, pix.n)
        imgs.append(cv2.cvtColor(img, cv2.COLOR_RGB2BGR))
        doc.close()
    return imgs if multi_view else imgs[0]



class STEP_Translater:
    def __init__(self, stp_fpath=None, slot_setting=None):
        self.stp_fpath = None
        self.model = None
        self.entities = {}
        self.e_gps = {}
        self.info = {}
        self.pts = {}
        self.dirs = {}
        self.axis2 = {}
        self.hlr_source_cache = {}
        self.slot_setting = copy.deepcopy(CAD_HELPER_HYP["滑槽偵測"] if slot_setting is None else slot_setting)
        if stp_fpath is not None:
            self.load(stp_fpath)
    def _split_params(self, data):
        ret, buf = [], []
        layer, in_text, i = 0, False, 0
        while i < len(data):
            ch = data[i]
            if ch == "'":
                buf.append(ch)
                if i + 1 < len(data) and data[i + 1] == "'":
                    buf.append(data[i + 1]); i += 2; continue
                in_text = not in_text
            elif not in_text and ch in "()":
                layer += 1 if ch == "(" else -1
                buf.append(ch)
            elif not in_text and ch == "," and layer == 0:
                ret.append("".join(buf).strip()); buf = []
            else:
                buf.append(ch)
            i += 1
        if buf: ret.append("".join(buf).strip())
        return ret
    def load(self, stp_fpath):
        self.stp_fpath = stp_fpath
        self.model = importers.importStep(stp_fpath)
        with open(stp_fpath, "r", encoding="utf-8", errors="ignore") as f:
            txt_data = f.read()
        entities = {}
        self.e_gps = {}
        self.info = {}
        self.pts = {}
        self.dirs = {}
        self.axis2 = {}
        for m in re.finditer(r"#(\d+)\s*=\s*(.*?);", txt_data, re.S):
            id_name = "#" + m.group(1)
            text = " ".join(m.group(2).split())
            f = re.match(r"([A-Z0-9_]+)\s*\((.*)\)$", text)
            func, items = (f.group(1), self._split_params(f.group(2))) if f else ("", [])
            entities[id_name] = {"id": id_name, "idx": int(m.group(1)), "func": func, "items": items, "refs": re.findall(r"#\d+", text), "text": text}
            if func not in self.e_gps: self.e_gps[func] = {}
            self.e_gps[func][id_name] = entities[id_name]
        self.entities = entities
        self._init_projection_cache()
        self._init_parse_stp()
        return entities
    def _cal_proj_hlr(self, stp_shape, view_normal_dir, x_dir, eta=1e-3):
        hlr = HLRBRep_Algo()
        hlr.Add(stp_shape.wrapped)
        hlr.Projector(HLRAlgo_Projector(gp_Ax2(gp_Pnt(), gp_Dir(*view_normal_dir), gp_Dir(*x_dir))))
        hlr.Update()
        hlr.Hide()
        hlr_shapes = HLRBRep_HLRToShape(hlr)
        visible = []
        hidden = []
        tan = []
        for target, items in (
            (visible, (hlr_shapes.VCompound(), hlr_shapes.OutLineVCompound())),
            (tan, (hlr_shapes.Rg1LineVCompound(),)),
            (hidden, (hlr_shapes.HCompound(), hlr_shapes.OutLineHCompound())),   ):
            for item in items:
                if item.IsNull(): continue
                BRepLib.BuildCurves3d_s(item, eta)
                for edge in Compound(item).Edges():  target.append(edge)
        return visible, hidden, tan
    def _init_projection_cache(self,):
        shape = self.model.val()
        self.hlr_source_cache = {}
        for view_name in VIEW_DIRECTION:
            item = VIEW_DIRECTION[view_name]
            n = np.array(item["N"], dtype=float)
            u = np.array(item["U"], dtype=float)
            n = n / np.linalg.norm(n)
            u = u / np.linalg.norm(u)
            r = np.cross(u, n)
            r = r / np.linalg.norm(r)
            visible, hidden, tan = self._cal_proj_hlr(shape, tuple(n.tolist()), tuple(r.tolist()))
            self.hlr_source_cache[view_name] = {"visible": visible, "hidden": hidden, "tan": tan, "N": n, "U": u, "R": r}
        return self.hlr_source_cache
    def get_hlr(self, view_name):
        return self.hlr_source_cache[view_name]
    def union_of_face_claims(self, keys=None):
        face_claims = self.info.get("face_claims", {})
        if keys is None: keys = face_claims
        face_ids = []
        for key in keys: face_ids += face_claims.get(key, [])
        return list(dict.fromkeys(fid for fid in face_ids if fid is not None))
    def _set_face_claims(self, key, face_ids):
        face_claims = self.info.setdefault("face_claims", {})
        face_claims[key] = list(dict.fromkeys(fid for fid in face_ids if fid is not None))
        self.info["dimed_faces"] = self.union_of_face_claims()
        return face_claims[key]
    def _init_parse_stp(self,):
        self.gather_edges()
        self.gather_faces()
        self.gather_face_links()
        self.gather_center_lines()
        self.gather_holes()
        self.gather_hole_dims()
        self.refresh_feature_dims()
        self.gather_thread_features()
    def refresh_feature_dims(self, slot_setting=None):
        if slot_setting is not None: self.slot_setting = copy.deepcopy(slot_setting)
        if self.slot_setting.get("啟用", False): self.gather_slot_dims(bool(self.slot_setting.get("限正交方向", True)))
        else:
            self.info["slot_dims"] = []
            self._set_face_claims("slot_dims", [])
        self.gather_fillet_dims()
        self.gather_cyn_dims()
        self.gather_rib_dims()
        self.gather_plane_dims()
        return self.info
    def gather_rib_dims(self, entities=None):
        if entities is None : entities = self.entities
        self.info["rib_dims"] = []
        faces = self.info["faces"]
        dimed_faces = self.union_of_face_claims(("hole_dims", "slot_dims", "fillet_dims", "cyn_dims"))
        dimed_face_set = set(dimed_faces)
        axis_eta = 1e-3
        for fid in faces:
            if fid in dimed_face_set: continue
            this_face = faces[fid]
            if this_face["func"] != "PLANE": continue
            dir_n = this_face.get("dir_n")
            if dir_n is None: continue
            n = np.array(dir_n, dtype=float)
            n_len = np.linalg.norm(n)
            if n_len == 0: continue
            n = n / n_len
            comps = np.abs(n)
            zero_axes = [i for i in range(3) if comps[i] < axis_eta]
            if len(zero_axes) != 1: continue
            free_axis = zero_axes[0]
            nonzero_axes = [i for i in range(3) if i != free_axis]
            na = comps[nonzero_axes[0]]
            nb = comps[nonzero_axes[1]]
            kind = "chamfer" if abs(na - nb) < axis_eta else "rib"
            verts = []
            seen = set()
            for line_id in this_face["lines"]:
                line = self.info["lines"].get(line_id)
                if line is None: continue
                for p in (line.get("p1"), line.get("p2")):
                    if p is None or len(p) < 3: continue
                    key = (round(p[0], 6), round(p[1], 6), round(p[2], 6))
                    if key in seen: continue
                    seen.add(key)
                    verts.append([float(p[0]), float(p[1]), float(p[2])])
            if len(verts) < 2: continue
            w = None
            if kind == "chamfer":
                arr = np.array(verts, dtype=float)
                w = round(float(arr[:, nonzero_axes[0]].max() - arr[:, nonzero_axes[0]].min()), 3)
            dim_pts = []
            aux_lines = []
            if kind == "rib":
                slope_line = None
                end_items = []
                for line_id in this_face["lines"]:
                    line = self.info["lines"].get(line_id)
                    if line is None or line.get("unit_vector") is None: continue
                    next_ids = [l["next_face"] for l in self.info["face_links"].get(fid, []) if l["edge"] == line_id]
                    if not next_ids: continue
                    nf = faces.get(next_ids[0])
                    if nf is None: continue
                    nf_dir = nf.get("dir_n")
                    if nf["func"] == "PLANE" and nf_dir is not None and abs(nf_dir[free_axis]) > 1 - axis_eta:
                        if slope_line is None: slope_line = line
                    else:
                        end_items.append((line, nf, next_ids[0]))
                if slope_line is not None:
                    s1 = np.array(slope_line["p1"], dtype=float)
                    s2 = np.array(slope_line["p2"], dtype=float)
                    s_dir = s2 - s1
                    for end_line, nf, nfid in end_items:
                        e_mid = np.array(end_line["p_mid"], dtype=float)
                        d1 = sum((s1[a] - e_mid[a]) ** 2 for a in nonzero_axes)
                        d2 = sum((s2[a] - e_mid[a]) ** 2 for a in nonzero_axes)
                        p_end = s1 if d1 <= d2 else s2
                        if nf["func"] == "PLANE":
                            dim_pts.append(p_end.tolist())
                            continue
                        if nf["func"] != "CYLINDRICAL_SURFACE": continue
                        wall = None
                        for l2 in self.info["face_links"].get(nfid, []):
                            if l2["edge_type"] != "line": continue
                            if l2["next_face"] == fid: continue
                            wf = faces.get(l2["next_face"])
                            if wf is None or wf["func"] != "PLANE": continue
                            w_dir = wf.get("dir_n")
                            if w_dir is None or abs(w_dir[free_axis]) > axis_eta: continue
                            wall = wf
                            break
                        if wall is None or wall.get("org") is None: continue
                        w_org = np.array(wall["org"], dtype=float)
                        w_n = np.array(wall["dir_n"], dtype=float)
                        denom = float(np.dot(s_dir, w_n))
                        if abs(denom) < 1e-9: continue
                        t = float(np.dot(w_org - p_end, w_n)) / denom
                        inter_pt = p_end + s_dir * t
                        dim_pts.append(inter_pt.tolist())
                        aux_lines.append({"p1":p_end.tolist(), "p2":inter_pt.tolist()})
            self.info["rib_dims"].append({"id":fid, "kind":kind, "org":this_face.get("org"), "dir_n":n.tolist(), "free_axis":free_axis, "verts":verts, "w":w, "dim_pts":dim_pts, "aux_lines":aux_lines})
            dimed_faces.append(fid)
            dimed_face_set.add(fid)
        self._set_face_claims("rib_dims", [item["id"] for item in self.info["rib_dims"]])
        return self.info["rib_dims"]
    def gather_edges(self, entities=None):
        if entities is None : entities = self.entities
        self.info["circles"] = {}
        self.info["lines"] = {}
        self.pts = {}
        self.dirs = {}
        self.axis2 = {}
        for id in entities :
            e = entities[id]
            e_func = e["func"]
            if e_func == "CARTESIAN_POINT":
                nums = get_nums(e["items"][1])
                self.pts[id] = nums
            elif e_func == "DIRECTION":
                nums = get_nums(e["items"][1])
                self.dirs[id] = nums
        for id in entities :
            e = entities[id]
            if e["func"] == "AXIS2_PLACEMENT_3D":
                org = self.pts.get(e["items"][1])
                dir_n = self.dirs.get(e["items"][2]) if len(e["items"]) > 2 else None
                self.axis2[id] = {"org":org, "dir_n":dir_n, "axis1":dir_n, "axis2":self.dirs.get(e["items"][3]) if len(e["items"]) > 3 else None}
        for id in entities :
            e = entities[id]
            if e["func"] != "EDGE_CURVE": continue
            p1 = self.pts.get(entities[e["items"][1]]["refs"][0]) if e["items"][1] in entities and entities[e["items"][1]]["refs"] else None
            p2 = self.pts.get(entities[e["items"][2]]["refs"][0]) if e["items"][2] in entities and entities[e["items"][2]]["refs"] else None
            curve_id = e["items"][3]
            if curve_id not in entities: continue
            curve = entities[curve_id]
            if curve["func"] == "LINE" and p1 is not None and p2 is not None:
                vec = [p2[i] - p1[i] for i in range(3)]
                dist = sum(ix * ix for ix in vec) ** 0.5
                unit_vector = [ix / dist for ix in vec] if dist != 0 else None
                p_mid = [(p1[i] + p2[i]) / 2 for i in range(3)]
                self.info["lines"][id] = {"id":id, "p1":p1, "p2":p2, "p_mid":p_mid, "unit_vector":unit_vector, "length":dist}
            elif curve["func"] == "CIRCLE":
                ax = self.axis2.get(curve["items"][1], {})
                self.info["circles"][id] = {"id":id, "org":ax.get("org"), "axis1":ax.get("axis1"), "axis2":ax.get("axis2"), "r":float(curve["items"][2])}
        return self.info["lines"], self.info["circles"]
    def gather_faces(self, entities=None):
        if entities is None : entities = self.entities
        self.info["faces"] = {}
        for id in entities :
            e = entities[id]
            if e["func"] != "ADVANCED_FACE": continue
            surf_id = e["items"][2]
            if surf_id not in entities: continue
            surf = entities[surf_id]
            if surf["func"] not in ["PLANE", "CYLINDRICAL_SURFACE", "CONICAL_SURFACE", "TOROIDAL_SURFACE"]: continue
            lines, circles, loops = [], [], []
            for bound_id in re.findall(r"#\d+", e["items"][1]):
                if bound_id not in entities: continue
                this_loop = {"outer":entities[bound_id]["func"] == "FACE_OUTER_BOUND", "lines":[], "circles":[]}
                for loop_id in entities[bound_id]["refs"]:
                    if loop_id not in entities: continue
                    for edge_item_id in entities[loop_id]["refs"]:
                        if edge_item_id not in entities: continue
                        edge_refs = entities[edge_item_id]["refs"]
                        if not edge_refs: continue
                        edge_id = edge_refs[0]
                        if edge_id in self.info["lines"]:
                            if edge_id not in lines: lines.append(edge_id)
                            if edge_id not in this_loop["lines"]: this_loop["lines"].append(edge_id)
                        if edge_id in self.info["circles"]:
                            if edge_id not in circles: circles.append(edge_id)
                            if edge_id not in this_loop["circles"]: this_loop["circles"].append(edge_id)
                loops.append(this_loop)
            ax = self.axis2.get(surf["items"][1], {})
            face_info = {"id":id, "func":surf["func"], "org":ax.get("org"), "lines":lines, "circles":circles, "loops":loops}
            if surf["func"] == "PLANE":
                face_info["dir_n"] = ax.get("dir_n")
                face_info["same_sense"] = e["items"][-1] == ".T."
            if surf["func"] == "CYLINDRICAL_SURFACE":
                face_info["dir_n"] = ax.get("dir_n")
                face_info["r"] = float(surf["items"][2])
                face_info["body"] = "inside" if e["items"][-1] == ".T." else "outside"
            elif surf["func"] == "CONICAL_SURFACE":
                face_info["dir_n"] = ax.get("dir_n")
                face_info["r"] = float(surf["items"][2])
                face_info["semi_angle"] = float(surf["items"][3])
                face_info["cone_type"] = "full" if len(circles) <= 1 else "frustum"
                cone_r = face_info["r"]
                cone_h_source = "surface_r"
                if len(circles) == 1 and circles[0] in self.info["circles"]:
                    cone_r = self.info["circles"][circles[0]]["r"]
                    cone_h_source = "single_circle_r"
                tan_angle = math.tan(face_info["semi_angle"])
                face_info["cone_h"] = cone_r / tan_angle if tan_angle != 0 else None
                face_info["cone_h_source"] = cone_h_source
            elif surf["func"] == "TOROIDAL_SURFACE":
                face_info["dir_n"] = ax.get("dir_n")
            self.info["faces"][id] = face_info
        return self.info["faces"]
    def gather_face_links(self, entities=None):
        if entities is None : entities = self.entities
        self.info["edge_to_faces"] = {}
        self.info["face_links"] = {}
        for face_id in self.info["faces"]:
            face = self.info["faces"][face_id]
            self.info["face_links"][face_id] = []
            for edge_id in face["lines"]:
                if edge_id not in self.info["edge_to_faces"]: self.info["edge_to_faces"][edge_id] = []
                self.info["edge_to_faces"][edge_id].append(face_id)
            for edge_id in face["circles"]:
                if edge_id not in self.info["edge_to_faces"]: self.info["edge_to_faces"][edge_id] = []
                self.info["edge_to_faces"][edge_id].append(face_id)
        for edge_id in self.info["edge_to_faces"]:
            edge_type = "circle" if edge_id in self.info["circles"] else "line" if edge_id in self.info["lines"] else "unknown"
            faces = self.info["edge_to_faces"][edge_id]
            for face_id in faces:
                for next_face_id in faces:
                    if next_face_id == face_id: continue
                    self.info["face_links"][face_id].append({"edge":edge_id, "edge_type":edge_type, "next_face":next_face_id})
        return self.info["face_links"]
    def gather_center_lines(self, entities=None):
        if entities is None : entities = self.entities
        faces = self.info["faces"]
        self.info["centerline_raw_pts"] = []
        for fid in faces:
            this_face = faces[fid]
            f_type = this_face["func"]
            if f_type not in ["CYLINDRICAL_SURFACE", "CONICAL_SURFACE", "TOROIDAL_SURFACE"]: continue
            if f_type == "CYLINDRICAL_SURFACE" and len(this_face["lines"]) > 1: continue
            circle_items = [self.info["circles"][circle_id] for circle_id in this_face["circles"] if circle_id in self.info["circles"] and self.info["circles"][circle_id].get("org") is not None]
            if not circle_items: continue
            circle1 = circle_items[0]
            circle_org = np.array(circle1["org"], dtype=float)
            r = float(circle1.get("r", 0))
            dir_n = this_face.get("dir_n") if this_face.get("dir_n") is not None else circle1.get("axis1")
            if dir_n is None: continue
            axis_dir = np.array(dir_n, dtype=float)
            axis_len = np.linalg.norm(axis_dir)
            if axis_len == 0: continue
            axis_dir = axis_dir / axis_len
            x_dir = circle1.get("axis2")
            if x_dir is None:
                ref_dir = np.array([1, 0, 0], dtype=float)
                if cal_collinear(axis_dir, ref_dir) is not None:
                    ref_dir = np.array([0, 1, 0], dtype=float)
                x_dir = np.cross(axis_dir, ref_dir)
            x_dir = np.array(x_dir, dtype=float)
            x_dir = x_dir - axis_dir * float(np.dot(x_dir, axis_dir))
            x_len = np.linalg.norm(x_dir)
            if x_len == 0: continue
            x_dir = x_dir / x_len
            y_dir = np.cross(axis_dir, x_dir)
            y_len = np.linalg.norm(y_dir)
            if y_len == 0: continue
            y_dir = y_dir / y_len
            all_lines = []
            if f_type == "CYLINDRICAL_SURFACE":
                if len(circle_items) >= 2:
                    all_lines.append({"cen_type":"軸線", "dir_n":axis_dir.tolist(), "p1":circle_items[0]["org"], "p2":circle_items[1]["org"]})
                all_lines.append({"cen_type":"十字", "dir_n":axis_dir.tolist(), "p1":(circle_org + x_dir * r).tolist(), "p2":(circle_org - x_dir * r).tolist()})
                all_lines.append({"cen_type":"十字", "dir_n":axis_dir.tolist(), "p1":(circle_org + y_dir * r).tolist(), "p2":(circle_org - y_dir * r).tolist()})
            elif f_type == "CONICAL_SURFACE":
                if this_face.get("cone_type") == "full":
                    cone_h = this_face.get("cone_h")
                    if cone_h is not None:
                        all_lines.append({"cen_type":"軸線", "dir_n":axis_dir.tolist(), "p1":circle_org.tolist(), "p2":(circle_org - axis_dir * float(cone_h)).tolist()})
                elif len(circle_items) >= 2:
                    all_lines.append({"cen_type":"軸線", "dir_n":axis_dir.tolist(), "p1":circle_items[0]["org"], "p2":circle_items[1]["org"]})
                all_lines.append({"cen_type":"十字", "dir_n":axis_dir.tolist(), "p1":(circle_org + x_dir * r).tolist(), "p2":(circle_org - x_dir * r).tolist()})
                all_lines.append({"cen_type":"十字", "dir_n":axis_dir.tolist(), "p1":(circle_org + y_dir * r).tolist(), "p2":(circle_org - y_dir * r).tolist()})
            elif f_type == "TOROIDAL_SURFACE":
                if len(circle_items) >= 2:
                    all_lines.append({"cen_type":"軸線", "dir_n":axis_dir.tolist(), "p1":circle_items[0]["org"], "p2":circle_items[1]["org"]})
            self.info["centerline_raw_pts"] += all_lines
        return self.info["centerline_raw_pts"]
    def gather_holes(self, entities=None):
        if entities is None : entities = self.entities
        self.info["holes"] = []
        faces = self.info["faces"]
        links = self.info["face_links"]
        type_notes = {"PLANE":"PLANE", "CYLINDRICAL_SURFACE":"CYN", "CONICAL_SURFACE":"CON", "TOROIDAL_SURFACE":"TOR"}
        hole_keys = set()
        def extract(circle_id, this_face_id):
            link_list = []
            note_list = []
            used_faces = [this_face_id]
            while True:
                next_face_id = None
                for link in links.get(this_face_id, []):
                    if link["edge"] == circle_id and link["next_face"] not in used_faces:
                        next_face_id = link["next_face"]
                        break
                if next_face_id is None:
                    this_face = faces[this_face_id]
                    if this_face["func"] == "CONICAL_SURFACE" and len(this_face["circles"]) == 1: break
                    raise RuntimeError(f"unexpected hole topology, next face not found: {this_face_id}")
                next_face = faces[next_face_id]
                next_type = next_face["func"]
                link_list.append(next_face_id)
                if next_type == "PLANE" and len(next_face["circles"]) == 1 and len(next_face["lines"]) < 1:
                    note_list.append("BPLANE")
                else:
                    note_list.append(type_notes.get(next_type, next_type))
                next_circle_id = None
                if next_type == "PLANE":
                    if not (len(next_face["circles"]) == 2 and len(next_face["lines"]) == 0): break
                    next_face2 = None
                    for next_link in links.get(next_face_id, []):
                        if next_link["edge"] == circle_id: continue
                        if next_link["next_face"] in used_faces: continue
                        next_circle_id = next_link["edge"]
                        next_face2 = faces[next_link["next_face"]]
                        break
                    if next_circle_id is None: raise RuntimeError(f"unexpected hole topology, plane next circle not found: {next_face_id}")
                    if next_face2["func"] == "CYLINDRICAL_SURFACE" and next_face2["body"] == "inside": break
                elif next_type == "CYLINDRICAL_SURFACE":
                    if next_face["body"] == "inside": break
                    if len(next_face["lines"]) >= 2: break
                elif next_type == "CONICAL_SURFACE":
                    if len(next_face["circles"]) == 1: break
                elif next_type == "TOROIDAL_SURFACE":
                    pass
                if next_circle_id is None:
                    for next_link in links.get(next_face_id, []):
                        if next_link["edge"] == circle_id: continue
                        if next_link["next_face"] in used_faces: continue
                        next_circle_id = next_link["edge"]
                        break
                if next_circle_id is None:
                    if next_type == "CONICAL_SURFACE" and len(next_face["circles"]) == 1: break
                    raise RuntimeError(f"unexpected hole topology, next circle not found: {next_face_id}")
                circle_id = next_circle_id
                this_face_id = next_face_id
                used_faces.append(next_face_id)
            return link_list, note_list
        for this_id in faces:
            this_face = faces[this_id]
            if this_face["func"] != "CYLINDRICAL_SURFACE": continue
            if len(this_face["lines"]) >= 2: continue
            if this_face["body"] == "inside": continue
            if len(this_face["circles"]) < 2: continue
            try:
                c1, c2 = this_face["circles"][0], this_face["circles"][1]
                link_list1, note_list1 = extract(c1, this_id)
                link_list2, note_list2 = extract(c2, this_id)
                link_list1.reverse()
                note_list1.reverse()
                link_list = link_list1 + [this_id] + link_list2
                note_list = note_list1 + ["CYN"] + note_list2
                plane_idxs = [i for i in range(len(note_list)) if note_list[i] == "PLANE"]
                if len(plane_idxs) >= 2:
                    first_plane_index = plane_idxs[0]
                    end_plane_index = plane_idxs[-1]
                    link_list = link_list[first_plane_index:end_plane_index + 1]
                    note_list = note_list[first_plane_index:end_plane_index + 1]
                if note_list[-1] == "CON" and note_list[0] != "CON":
                    link_list = link_list[::-1]
                    note_list = note_list[::-1]
                elif note_list[-1] == "BPLANE" and note_list[0] != "BPLANE":
                    link_list = link_list[::-1]
                    note_list = note_list[::-1]
                elif note_list[0] == "PLANE" and note_list[-1] == "PLANE":
                    d1 = None
                    d2 = None
                    for link in links.get(link_list[0], []):
                        if link["edge_type"] == "circle" and link["next_face"] == link_list[1]:
                            d1 = self.info["circles"][link["edge"]]["r"] * 2
                            break
                    for link in links.get(link_list[-1], []):
                        if link["edge_type"] == "circle" and link["next_face"] == link_list[-2]:
                            d2 = self.info["circles"][link["edge"]]["r"] * 2
                            break
                    if d1 is None or d2 is None: raise RuntimeError(f"unexpected hole topology, end circle diameter not found: {this_id}")
                    if d1 > d2:
                        link_list = link_list[::-1]
                        note_list = note_list[::-1]
                link_raw = link_list[:]
                note_raw = note_list[:]
                if "BPLANE" in note_raw: continue
                main_cyn_idx = None
                main_r = None
                for i in range(len(note_list)):
                    if note_list[i] != "CYN": continue
                    main_cyn_idx = i
                    main_r = faces[link_list[i]].get("r")
                    break
                if main_cyn_idx is not None:
                    for i in range(main_cyn_idx + 1, len(note_list) - 2):
                        if note_list[i:i + 3] != ["PLANE", "CYN", "PLANE"]: continue
                        head_r = faces[link_list[i + 1]].get("r")
                        if main_r is None or head_r is None or head_r <= main_r: continue
                        link_list = link_list[:i + 3]
                        note_list = note_list[:i + 3]
                        break
                link_key = tuple(link_list)
                if link_key in hole_keys or tuple(reversed(link_list)) in hole_keys: continue
                hole_keys.add(link_key)
                self.info["holes"].append({"id":this_id, "link_raw":link_raw, "link":link_list, "seq_raw":"-".join(note_raw), "seq":"-".join(note_list)})
            except Exception:
                continue
        return self.info["holes"]
    def gather_hole_dims(self, entities=None):
        if entities is None : entities = self.entities
        self.info["hole_dims"] = []
        holes = self.info["holes"]
        faces = self.info["faces"]
        links = self.info["face_links"]
        circles = self.info["circles"]
        dimed_faces = []
        for this_hole in holes :
            try:
                seq = this_hole["seq"].split("-")
                link = this_hole["link"]
                reason = []
                p_idx_in_link = [i for i in range(len(seq)) if seq[i] == "PLANE"]
                cyn_idx_in_link = [i for i in range(len(seq)) if seq[i] == "CYN"]
                if len(cyn_idx_in_link) < 1 or len(p_idx_in_link) < 1:
                    self.info["hole_dims"].append({"id":this_hole["id"], "seq":this_hole["seq"], "link":link, "kind":"unknown", "reason":"missing CYN or PLANE", "text_top":"", "text_bottom":""})
                    continue
                is_through = seq[0] != "CON"
                is_cbore = "PLANE" in seq[1:-1]
                joint_circle_ids = {}
                for i in range(len(link) - 1):
                    for this_link in links.get(link[i], []):
                        if this_link["next_face"] != link[i + 1]: continue
                        if this_link["edge_type"] != "circle": continue
                        joint_circle_ids[(i, i + 1)] = this_link["edge"]
                        break
                main_cyn_idx = cyn_idx_in_link[0]
                main_cyn_id = link[main_cyn_idx]
                main_cyn = faces[main_cyn_id]
                if is_through and main_cyn_idx > 0 and seq[main_cyn_idx - 1] == "PLANE":
                    end_plane_id = link[main_cyn_idx - 1]
                    end_circle_id = joint_circle_ids.get((main_cyn_idx - 1, main_cyn_idx))
                    if end_circle_id in circles:
                        end_circle = circles[end_circle_id]
                        end_org = end_circle.get("org")
                        end_r = end_circle.get("r")
                        if end_org is not None and end_r is not None:
                            for circle_id in faces[end_plane_id].get("circles", []):
                                if circle_id == end_circle_id or circle_id not in circles: continue
                                this_circle = circles[circle_id]
                                this_org = this_circle.get("org")
                                this_r = this_circle.get("r")
                                if this_org is None or this_r is None: continue
                                dist = sum((this_org[i] - end_org[i]) ** 2 for i in range(3)) ** 0.5
                                if dist + this_r < end_r - 1e-6:
                                    is_through = False
                                    reason.append("end plane has inner circle")
                                    break
                main_start_plane_idx = p_idx_in_link[-2] if is_cbore and len(p_idx_in_link) >= 2 else p_idx_in_link[-1]
                main_start_plane_id = link[main_start_plane_idx]
                main_start_circle_id = joint_circle_ids.get((main_start_plane_idx - 1, main_start_plane_idx))
                main_start_org = circles[main_start_circle_id]["org"] if main_start_circle_id in circles else faces[main_start_plane_id]["org"]
                if main_start_circle_id is None: reason.append("main start circle not found")
                main_end_circle_id = joint_circle_ids.get((main_cyn_idx - 1, main_cyn_idx))
                main_end_org = circles[main_end_circle_id]["org"] if main_end_circle_id in circles else None
                if main_start_org is not None and main_end_org is not None:
                    main_dir = [main_start_org[i] - main_end_org[i] for i in range(3)]
                    main_dir_len = sum(v * v for v in main_dir) ** 0.5
                    dir_n = [round(v / main_dir_len, 6) for v in main_dir] if main_dir_len != 0 else main_cyn.get("dir_n")
                else:
                    dir_n = main_cyn.get("dir_n")
                for this_idx in cyn_idx_in_link:
                    dimed_faces.append(link[this_idx])
                thread_cyn_idx = None
                drill_cyn_idx = None
                is_thread = False
                is_full_thread = False
                for i in range(len(cyn_idx_in_link) - 1):
                    if cyn_idx_in_link[i + 1] != cyn_idx_in_link[i] + 1: continue
                    is_thread = True
                    is_full_thread = False
                    drill_cyn_idx = cyn_idx_in_link[i]
                    thread_cyn_idx = cyn_idx_in_link[i + 1]
                    break
                if not is_thread:
                    this_minor_d = round(main_cyn["r"] * 2, 2)
                    for thread_name in THREAD_SIZE_ITEMS:
                        thread_item = THREAD_SIZE_ITEMS[thread_name]
                        if round(thread_item["minor_d"], 2) != this_minor_d: continue
                        is_thread = True
                        is_full_thread = True
                        thread_cyn_idx = main_cyn_idx
                        break
                cbore_d = None
                cbore_h = None
                cbore_plane_id = None
                if is_cbore :
                    cbore_plane_id = link[p_idx_in_link[-2]]
                    cbore_bottom_circle_id = joint_circle_ids.get((p_idx_in_link[-2], p_idx_in_link[-2] + 1))
                    cbore_top_circle_id = joint_circle_ids.get((p_idx_in_link[-1] - 1, p_idx_in_link[-1]))
                    cbore_bottom_org = circles[cbore_bottom_circle_id]["org"] if cbore_bottom_circle_id in circles else None
                    cbore_top_org = circles[cbore_top_circle_id]["org"] if cbore_top_circle_id in circles else None
                    cbore_h = round(sum((cbore_top_org[i] - cbore_bottom_org[i]) ** 2 for i in range(3)) ** 0.5, 3) if cbore_top_org is not None and cbore_bottom_org is not None else None
                    cbore_ds = [circles[circle_id]["r"] * 2 for circle_id in [cbore_bottom_circle_id, cbore_top_circle_id] if circle_id in circles]
                    cbore_d = round(max(cbore_ds), 3) if cbore_ds else None
                    dimed_faces.append(cbore_plane_id)
                thread_name = None
                pitch = None
                thread_h = None
                thread_cyn_id = None
                thread_minor_d = None
                if is_thread :
                    thread_cyn_id = link[thread_cyn_idx]
                    thread_cyn = faces[thread_cyn_id]
                    thread_minor_d = round(thread_cyn["r"] * 2, 3)
                    for this_thread_name in THREAD_SIZE_ITEMS:
                        thread_item = THREAD_SIZE_ITEMS[this_thread_name]
                        if round(thread_item["minor_d"], 2) != round(thread_minor_d, 2): continue
                        thread_name = this_thread_name
                        pitch = thread_item["pitch"]
                        break
                    if thread_name is None:
                        thread_name = "M?"
                        pitch = "?"
                        reason.append("thread size not found")
                    if is_full_thread :
                        thread_h = "full"
                    else :
                        drill_cyn_id = link[drill_cyn_idx]
                        thread_circle_id = joint_circle_ids.get((drill_cyn_idx, thread_cyn_idx))
                        if thread_circle_id is not None and main_start_org is not None and circles[thread_circle_id]["org"] is not None:
                            this_circle_org = circles[thread_circle_id]["org"]
                            thread_h = round(sum((main_start_org[i] - this_circle_org[i]) ** 2 for i in range(3)) ** 0.5, 3)
                        else:
                            reason.append("thread depth circle not found")
                else :
                    hole_h = None
                    if not is_through:
                        hole_end_circle_id = joint_circle_ids.get((main_cyn_idx - 1, main_cyn_idx))
                        hole_end_org = circles[hole_end_circle_id]["org"] if hole_end_circle_id in circles else None
                        if main_start_org is not None and hole_end_org is not None:
                            hole_h = round(sum((main_start_org[i] - hole_end_org[i]) ** 2 for i in range(3)) ** 0.5, 3)
                        else:
                            reason.append("hole depth circle not found")
                    hole_d = round(main_cyn["r"] * 2, 3)
                if is_thread :
                    if is_through :
                        depth = "攻穿"
                    elif thread_h is None:
                        depth = "牙深?"
                    else :
                        depth = f"牙深{thread_h}"
                    words1 = f"{thread_name}X{pitch},{depth}"
                    kind = "thread"
                else :
                    if is_through :
                        depth = "貫穿"
                    elif hole_h is None:
                        depth = "深?"
                    else :
                        depth = f"深{hole_h}"
                    words1 = f"%%c{hole_d},{depth}"
                    kind = "hole"
                words2 = ""
                if is_cbore :
                    if cbore_d is None or cbore_h is None:
                        words2 = "%%c?,深?"
                        reason.append("cbore dim not found")
                    else:
                        words2 = f"%%c{cbore_d},深{cbore_h}"
                self.info["hole_dims"].append({"id":this_hole["id"], "seq":this_hole["seq"], "seq_raw":this_hole.get("seq_raw", this_hole["seq"]), "link":link, "link_raw":this_hole.get("link_raw", link), "kind":kind, "is_thread":is_thread, "is_full_thread":is_full_thread, "is_through":is_through, "is_cbore":is_cbore, "main_cyn":main_cyn_id, "thread_cyn":thread_cyn_id, "cbore_plane":cbore_plane_id, "cbore_d":cbore_d, "text_top":words1, "text_bottom":words2, "org":main_start_org, "dir_n":dir_n, "reason":"; ".join(reason)})
            except Exception:
                continue
        self._set_face_claims("hole_dims", dimed_faces)
        return self.info["hole_dims"]
    def gather_slot_dims(self, ortho=True):
        self.info["slot_dims"] = []
        faces = self.info["faces"]
        links = self.info["face_links"]
        circles = self.info["circles"]
        cyn_ids = [fid for fid in faces if faces[fid]["func"] == "CYLINDRICAL_SURFACE" and faces[fid].get("body") == "outside"]
        slot_candidates = []
        for i in range(len(cyn_ids)):
            for j in range(i + 1, len(cyn_ids)):
                fid1, fid2 = cyn_ids[i], cyn_ids[j]
                try:
                    f1, f2 = faces[fid1], faces[fid2]
                    if f1.get("r") is None or f2.get("r") is None: continue
                    r = float(f1["r"])
                    match_tol = max(1e-3, r * 1e-3)
                    if abs(r - float(f2["r"])) > match_tol: continue
                    if f1.get("dir_n") is None or f2.get("dir_n") is None: continue
                    if cal_collinear(f1["dir_n"], f2["dir_n"]) is None: continue
                    if f1.get("org") is None or f2.get("org") is None: continue
                    nb1 = set(this_link["next_face"] for this_link in links.get(fid1, []) if this_link["edge_type"] == "line" and faces.get(this_link["next_face"], {}).get("func") == "PLANE")
                    nb2 = set(this_link["next_face"] for this_link in links.get(fid2, []) if this_link["edge_type"] == "line" and faces.get(this_link["next_face"], {}).get("func") == "PLANE")
                    common = sorted(nb1 & nb2)
                    if len(common) != 2: continue
                    axis = np.array(f1["dir_n"], dtype=float)
                    axis = axis / np.linalg.norm(axis)
                    org1 = np.array(f1["org"], dtype=float)
                    org2 = np.array(f2["org"], dtype=float)
                    delta = org2 - org1
                    slide = delta - axis * float(np.dot(delta, axis))
                    L_cc = float(np.linalg.norm(slide))
                    if L_cc < 1e-6: continue
                    slide = slide / L_cc
                    if ortho and all(cal_collinear(slide, base) is None for base in ((1.0, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0))): continue
                    plane_orgs, plane_normals = [], []
                    for plane_id in common:
                        plane = faces[plane_id]
                        if plane.get("org") is None or plane.get("dir_n") is None: break
                        plane_org = np.array(plane["org"], dtype=float)
                        plane_normal = np.array(plane["dir_n"], dtype=float)
                        normal_len = float(np.linalg.norm(plane_normal))
                        if normal_len == 0: break
                        plane_normal = plane_normal / normal_len
                        if abs(float(np.dot(plane_normal, axis))) > 1e-4 or abs(float(np.dot(plane_normal, slide))) > 1e-4: break
                        if any(abs(abs(float(np.dot(org - plane_org, plane_normal))) - r) > match_tol for org in (org1, org2)): break
                        plane_orgs.append(plane_org)
                        plane_normals.append(plane_normal)
                    if len(plane_normals) != 2: continue
                    if cal_collinear(plane_normals[0], plane_normals[1], eta=1e-4) is None: continue
                    plane_gap = abs(float(np.dot(plane_orgs[1] - plane_orgs[0], plane_normals[0])))
                    if abs(plane_gap - r * 2) > match_tol: continue
                    axial_vals = []
                    for fid in (fid1, fid2):
                        for cid in faces[fid]["circles"]:
                            this_org = circles.get(cid, {}).get("org")
                            if this_org is None: continue
                            axial_vals.append(float(np.dot(np.array(this_org, dtype=float), axis)))
                    depth = round(max(axial_vals) - min(axial_vals), 3) if len(axial_vals) >= 2 else None
                    is_through = True
                    for fid in (fid1, fid2):
                        for this_link in links.get(fid, []):
                            if this_link["edge_type"] != "circle": continue
                            nf = this_link["next_face"]
                            if nf in (fid1, fid2) or nf in common: continue
                            for loop in faces.get(nf, {}).get("loops", []):
                                if this_link["edge"] in loop["circles"] and loop["outer"]:
                                    is_through = False
                                    break
                            if not is_through: break
                        if not is_through: break
                    center = ((org1 + org2) / 2).tolist()
                    slot_candidates.append({"id":f"{fid1}-{fid2}", "cyn_ids":[fid1, fid2], "plane_ids":common, "r":r, "width":round(r * 2, 3), "org1":org1.tolist(), "org2":org2.tolist(), "center":center, "dir_axis":axis.tolist(), "dir_slide":slide.tolist(), "L_cc":round(L_cc, 3), "depth":depth, "is_through":is_through})
                except Exception:
                    continue
        used = set()
        for item in sorted(slot_candidates, key=lambda this_item: (this_item["L_cc"], this_item["id"])):
            if any(fid in used for fid in item["cyn_ids"]): continue
            self.info["slot_dims"].append(item)
            used.update(item["cyn_ids"])
        slot_faces = sum([item["cyn_ids"] + item["plane_ids"] for item in self.info["slot_dims"]], [])
        self._set_face_claims("slot_dims", slot_faces)
        return self.info["slot_dims"]
    def gather_fillet_dims(self, entities=None):
        if entities is None : entities = self.entities
        self.info["fillet_dims"] = []
        faces = self.info["faces"]
        dimed_faces = self.union_of_face_claims(("hole_dims", "slot_dims"))
        dimed_face_set = set(dimed_faces)
        for fid in faces:
            if fid in dimed_face_set: continue
            this_face = faces[fid]
            if this_face["func"] != "CYLINDRICAL_SURFACE": continue
            circles = this_face["circles"]
            lines = this_face["lines"]
            if len(lines) > 1 : is_fillet = True
            else : is_fillet = False
            if not is_fillet : continue
            org = this_face.get("org")
            dir_n = this_face.get("dir_n")
            arc_dir = None
            arc_dirs = []
            if org is not None and dir_n is not None:
                axis_org = np.array(org, dtype=float)
                axis_dir = np.array(dir_n, dtype=float)
                axis_len = np.linalg.norm(axis_dir)
                if axis_len != 0:
                    axis_dir = axis_dir / axis_len
                    for line_id in lines:
                        line = self.info["lines"].get(line_id)
                        if line is None or line.get("p_mid") is None: continue
                        p_mid = np.array(line["p_mid"], dtype=float)
                        axis_pt = axis_org + axis_dir * float(np.dot(p_mid - axis_org, axis_dir))
                        this_arc_dir = p_mid - axis_pt
                        this_len = np.linalg.norm(this_arc_dir)
                        if this_len == 0: continue
                        arc_dirs.append(this_arc_dir / this_len)
            if arc_dirs:
                arc_dir = np.sum(arc_dirs, axis=0)
                arc_len = np.linalg.norm(arc_dir)
                if arc_len == 0:
                    arc_dir = arc_dirs[0]
                else:
                    arc_dir = arc_dir / arc_len
                arc_dir = arc_dir.tolist()
            self.info["fillet_dims"].append({"id":fid, "org":org, "dir_n":dir_n, "r":this_face.get("r"), "arc_dir":arc_dir, "lines":lines, "circles":circles})
            dimed_faces.append(fid)
            dimed_face_set.add(fid)
        self._set_face_claims("fillet_dims", [item["id"] for item in self.info["fillet_dims"]])
        return self.info["fillet_dims"]
    def gather_cyn_dims(self,):
        self.info["cyn_dims"] = []
        faces = self.info["faces"]
        dimed_faces = self.union_of_face_claims(("hole_dims", "slot_dims", "fillet_dims"))
        dimed_face_set = set(dimed_faces)
        for fid in faces:
            if fid in dimed_face_set: continue
            this_face = faces[fid]
            if this_face["func"] != "CYLINDRICAL_SURFACE": continue
            self.info["cyn_dims"].append({"id":fid, "org":this_face.get("org"), "dir_n":this_face.get("dir_n"), "r":this_face.get("r"), "lines":this_face["lines"], "circles":this_face["circles"]})
            dimed_faces.append(fid)
            dimed_face_set.add(fid)
        self._set_face_claims("cyn_dims", [item["id"] for item in self.info["cyn_dims"]])
        return self.info["cyn_dims"]
    def gather_plane_dims(self,):
        self.info["plane_dims"] = []
        faces = self.info["faces"]
        dimed_faces = set(self.union_of_face_claims())
        for fid in faces:
            if fid in dimed_faces: continue
            this_face = faces[fid]
            if this_face["func"] != "PLANE": continue
            lines = this_face["lines"]
            circles = this_face["circles"]
            xs, ys, zs = [], [], []
            for line_id in lines:
                line = self.info["lines"].get(line_id)
                if line is None: continue
                for p in (line.get("p1"), line.get("p2")):
                    if p is None or len(p) < 3: continue
                    xs.append(float(p[0]))
                    ys.append(float(p[1]))
                    zs.append(float(p[2]))
            for circle_id in circles:
                circle = self.info["circles"].get(circle_id)
                if circle is None: continue
                org = circle.get("org")
                r = circle.get("r")
                if org is None or r is None or len(org) < 3: continue
                r = float(r)
                xs += [float(org[0]) - r, float(org[0]) + r]
                ys += [float(org[1]) - r, float(org[1]) + r]
                zs.append(float(org[2]))
            dir_n = this_face.get("dir_n")
            if dir_n is None:
                ent = self.entities.get(fid)
                surf = self.entities.get(ent["items"][2]) if ent is not None and len(ent["items"]) > 2 else None
                ax = self.axis2.get(surf["items"][1], {}) if surf is not None and surf["items"] else {}
                dir_n = ax.get("dir_n")
            self.info["plane_dims"].append({"id":fid, "org":this_face.get("org"), "dir_n":dir_n, "lines":lines, "circles":circles, "xmin":min(xs) if xs else None, "xmax":max(xs) if xs else None, "ymin":min(ys) if ys else None, "ymax":max(ys) if ys else None, "zmin":min(zs) if zs else None, "zmax":max(zs) if zs else None})
        return self.info["plane_dims"]
    def gather_thread_features(self,):
        self.info["thread_features"] = []
        for item in self.info.get("hole_dims", []):
            if not item.get("is_thread"): continue
            thread_cyn = self.info["faces"].get(item.get("thread_cyn"))
            org = item.get("org")
            dir_n = item.get("dir_n")
            if thread_cyn is None or org is None or dir_n is None: continue
            thread_minor_d = round(float(thread_cyn.get("r", 0)) * 2, 2)
            thread_major_d = None
            for thread_name in THREAD_SIZE_ITEMS:
                if round(THREAD_SIZE_ITEMS[thread_name]["minor_d"], 2) != thread_minor_d: continue
                thread_major_d = THREAD_SIZE_ITEMS[thread_name]["major_d"]
                break
            if thread_major_d is None: continue
            axis_dir = np.array(dir_n, dtype=float)
            axis_len = np.linalg.norm(axis_dir)
            if axis_len == 0: continue
            axis_dir = axis_dir / axis_len
            circle_orgs = []
            for circle_id in thread_cyn.get("circles", []):
                circle = self.info["circles"].get(circle_id)
                if circle is None or circle.get("org") is None: continue
                circle_orgs.append(circle["org"])
            if len(circle_orgs) < 2: continue
            org_arr = np.array(org, dtype=float)
            start_pt = min(circle_orgs, key=lambda p: float(np.linalg.norm(np.array(p, dtype=float) - org_arr)))
            start_arr = np.array(start_pt, dtype=float)
            end_pt = max(circle_orgs, key=lambda p: float(np.linalg.norm(np.array(p, dtype=float) - start_arr)))
            self.info["thread_features"].append({"org":org, "dir_n":axis_dir.tolist(), "start_pt":start_pt, "end_pt":end_pt, "major_d":thread_major_d, "minor_d":thread_minor_d, "is_through":item.get("is_through")})
        return self.info["thread_features"]
    def debug_print_entites(self,):
        for id in self.entities:
            print(id, self.entities[id])
    def debug_print_info(self,):
        for this_type in self.e_gps:
            print("Type = ", this_type)
            for id in self.e_gps[this_type]:
                print(id , self.e_gps[this_type][id])
    def debug_print_edges(self,):
        print("Edges")
        print("  Lines = ", len(self.info["lines"]))
        for id in sorted(self.info["lines"], key=lambda x: self.entities[x]["idx"]):
            item = self.info["lines"][id]
            print("    Line", id)
            print("      p1          = ", item["p1"])
            print("      p2          = ", item["p2"])
            print("      p_mid       = ", item["p_mid"])
            print("      unit_vector = ", item["unit_vector"])
            print("      length      = ", item["length"])
        print("  Circles = ", len(self.info["circles"]))
        for id in sorted(self.info["circles"], key=lambda x: self.entities[x]["idx"]):
            item = self.info["circles"][id]
            print("    Circle", id)
            print("      org   = ", item["org"])
            print("      axis1 = ", item["axis1"])
            print("      axis2 = ", item["axis2"])
            print("      r     = ", item["r"])
    def debug_print_holes(self,):
        print("Holes")
        print("  Holes = ", len(self.info["holes"]))
        for item in self.info["holes"]:
            print("    Hole", item["id"])
            print("      link = ", item["link"])
            print("      seq_raw = ", item["seq_raw"])
            print("      seq     = ", item["seq"])
    def debug_print_hole_dims(self,):
        for item in self.info["hole_dims"]:
            print("    Dim", item["seq"])
            print("      text_top     = ", item["text_top"])
            print("      text_bottom     = ", item["text_bottom"])
    def debug_print_faces(self,):
        print("Faces")
        print("  Faces = ", len(self.info["faces"]))
        for id in sorted(self.info["faces"], key=lambda x: self.entities[x]["idx"]):
            item = self.info["faces"][id]
            print("    Face", id)
            print("      func    = ", item["func"])
            print("      org     = ", item["org"])
            if "dir_n" in item: print("      dir_n   = ", item["dir_n"])
            if "r" in item: print("      r       = ", item["r"])
            if "semi_angle" in item: print("      semi_angle = ", item["semi_angle"])
            if "cone_type" in item: print("      cone_type = ", item["cone_type"])
            if "cone_h" in item: print("      cone_h = ", item["cone_h"])
            if "cone_h_source" in item: print("      cone_h_source = ", item["cone_h_source"])
            if "arc_dir" in item: print("      arc_dir = ", item["arc_dir"])
            if "body" in item: print("      body    = ", item["body"])
            print("      lines   = ", item["lines"])
            print("      circles = ", item["circles"])
    def debug_print_rib_dims(self,):
        print("Rib dims")
        print("  count = ", len(self.info["rib_dims"]))
        for item in self.info["rib_dims"]:
            print("    Face", item["id"], item["kind"])
            print("      dir_n     = ", item["dir_n"])
            print("      free_axis = ", item["free_axis"])
            print("      verts     = ", len(item["verts"]))

class View_Projector:
    def __init__(self, translater=None):
        self.translater = translater
        self.rotate_info = {"x": 0, "y": 0, "z": 0}
        self.rotation_matrix = np.eye(3)
        self.view_map_after_rotate = {"front": "front", "right": "right", "top": "top", "back": "back", "left": "left", "bottom": "bottom"}
        self.view_cache = {}
        self.view_image_cache = {}
        self.clean_eta = 1e-6
        self.spline_fit_tol = 1e-3
        self.line_merge_angle_tol = 0.05
        self.line_merge_dist_tol = 1e-2
        self.line_merge_gap_tol = 1e-2
        self.angle_digits = 3
        self.pos_digits = 6
        if translater is not None:
            self._init_view_images()
    def rotate(self, x=None, y=None, z=None):
        if x is None and y is None and z is None:
            return {"rotate_info": self.rotate_info.copy(), "rotation_matrix": self.rotation_matrix.copy(), "view_map_after_rotate": self.view_map_after_rotate.copy()}
        for key, val in {"x": x, "y": y, "z": z}.items():
            if val is None: continue
            self.rotate_info[key] = self.rotate_info.get(key, 0) + int(val)
        rx = math.radians((self.rotate_info["x"] % 4) * 90)
        ry = math.radians((self.rotate_info["y"] % 4) * 90)
        rz = math.radians((self.rotate_info["z"] % 4) * 90)
        mx = np.array([[1, 0, 0], [0, math.cos(rx), -math.sin(rx)], [0, math.sin(rx), math.cos(rx)]], dtype=float)
        my = np.array([[math.cos(ry), 0, math.sin(ry)], [0, 1, 0], [-math.sin(ry), 0, math.cos(ry)]], dtype=float)
        mz = np.array([[math.cos(rz), -math.sin(rz), 0], [math.sin(rz), math.cos(rz), 0], [0, 0, 1]], dtype=float)
        self.rotation_matrix = mz @ my @ mx
        view_names = ("front", "right", "top", "back", "left", "bottom")
        view_dir = {name: np.array(VIEW_DIRECTION[name]["N"], dtype=float) for name in view_names}
        self.view_map_after_rotate = {}
        for target_name in view_names:
            source_n = self.rotation_matrix.T @ view_dir[target_name]
            source_name = max(view_names, key=lambda name: float(np.dot(source_n, view_dir[name])))
            self.view_map_after_rotate[target_name] = source_name
        self._clear_cache()
        return {"rotate_info": self.rotate_info.copy(), "rotation_matrix": self.rotation_matrix.copy(), "view_map_after_rotate": self.view_map_after_rotate.copy()}
    def _clear_cache(self,):
        self.view_cache = {}
        return self.view_cache
    def _cal_view_axes(self, name):
        view = VIEW_DIRECTION[name]
        n = np.array(view["N"], dtype=float)
        u = np.array(view["U"], dtype=float)
        n = n / np.linalg.norm(n)
        u = u / np.linalg.norm(u)
        r = np.cross(u, n)
        r = r / np.linalg.norm(r)
        return n, u, r
    def _cal_view_theta(self, name):
        if name.startswith("iso"): return name, 0.0
        source_name = self.view_map_after_rotate[name]
        cache_item = self.translater.get_hlr(source_name)
        target_u = np.array(VIEW_DIRECTION[name]["U"], dtype=float)
        source_u = self.rotation_matrix.T @ target_u
        source_u = source_u / np.linalg.norm(source_u)
        theta = math.degrees(math.atan2(float(np.dot(source_u, cache_item["R"])), float(np.dot(source_u, cache_item["U"]))))
        return source_name, theta
    def proj_pt(self, pts, name="front"):
        pts = np.array(pts, dtype=float)
        if pts.ndim == 1: pts = pts.reshape(1, 3)
        n, u, r = self._cal_view_axes(name)
        matrix = np.array([r, u], dtype=float)
        return pts @ self.rotation_matrix.T @ matrix.T
    def dir_in_view(self, dir_n, name="front", eta=1e-2):
        d = self.rotation_matrix @ np.array(dir_n, dtype=float)
        return cal_collinear(d, VIEW_DIRECTION[name]["N"], eta)
    def get_view(self, name="front"):
        if name in self.view_cache: return self.view_cache[name]
        source_name, theta = self._cal_view_theta(name)
        k = int(round(theta / 90.0)) % 4
        image = self._rot90_image(self.view_image_cache[source_name], k)
        n, u, r = self._cal_view_axes(name)
        ret = {"visible":image["visible"], "hidden":image["hidden"], "tan":image["tan"], "bbox":image["bbox"], "label":VIEW_DIRECTION[name]["label"], "N":VIEW_DIRECTION[name]["N"], "U":VIEW_DIRECTION[name]["U"], "R":tuple(r.tolist()), "is_iso":name.startswith("iso"), "source_name":source_name, "theta":theta}
        self.view_cache[name] = ret
        return ret
    def _build_section_view(self, setting):
        if self.translater is None or self.translater.model is None: raise ValueError("STEP model is not loaded")
        rotation_matrix = np.array(setting.get("rotation_matrix", self.rotation_matrix), dtype=float)
        direction = setting["direction"]
        look_from = setting["look_from"]
        position = float(setting.get("absolute_position", setting["position"]))
        _, front_u, front_r = self._cal_view_axes("front")
        if direction == "horizontal":
            look_display = front_u if look_from == "top" else -front_u
            origin_display = front_u * position
            x_display = front_r
        else:
            look_display = front_r if look_from == "right" else -front_r
            origin_display = front_r * position
            x_display = np.cross(front_u, look_display)
            x_display = x_display / np.linalg.norm(x_display)
        look_source = rotation_matrix.T @ look_display
        origin_source = rotation_matrix.T @ origin_display
        x_source = rotation_matrix.T @ x_display
        look_source = look_source / np.linalg.norm(look_source)
        x_source = x_source / np.linalg.norm(x_source)
        plane = cq.Plane(origin=tuple(origin_source.tolist()), xDir=tuple(x_source.tolist()), normal=tuple(look_source.tolist()))
        source_shape = self.translater.model.val()
        source_wp = cq.Workplane(plane).newObject([source_shape])
        section_wp = source_wp.section()
        section_wires = section_wp.wires().vals()
        if not section_wires: raise ValueError(f"section does not intersect model: {direction} {position:g}")
        for wire in section_wires:
            for edge in wire.Edges(): BRepLib.BuildCurves3d_s(edge.wrapped, self.clean_eta)
        cut_size = source_shape.BoundingBox().DiagonalLength * 10.0
        cut_tool = cq.Workplane(plane).rect(cut_size, cut_size).extrude(cut_size).val()
        kept_shape = source_shape.cut(cut_tool)
        if kept_shape is None or kept_shape.isNull(): raise ValueError("section retained half is empty")
        visible, hidden, tan = self.translater._cal_proj_hlr(kept_shape, tuple(look_source.tolist()), tuple(x_source.tolist()))
        image = {}
        for group_name, edges in (("visible", visible), ("hidden", hidden), ("tan", tan)):
            if not edges:
                image[group_name] = []
                continue
            tmp_doc = DxfDocument()
            tmp_doc.add_shape(cq.Workplane("XY").newObject(list(edges)), "0")
            image[group_name] = self._collect_primitives(tmp_doc.document.modelspace())
        image = self._clean(image)
        cut_entities = []
        for wire in section_wires: cut_entities += self._wire_2_dxf_entities(wire, plane)
        cut_image = {"visible":self._collect_primitives(cut_entities), "hidden":[], "tan":[]}
        cut = self._clean(cut_image)["visible"]
        cut_faces = []
        hatch_warnings = []
        if any(not wire.IsClosed() for wire in section_wires):
            hatch_warnings.append("section contains open wire, hatch skipped")
        else:
            min_area = float(setting.get("hatch_min_area", 1e-6))
            wire_items = []
            wire_face_failed = False
            for wire_i, wire in enumerate(section_wires):
                try:
                    face = cq.Face.makeFromWires(wire)
                    area = abs(float(face.Area()))
                    if area <= min_area:
                        hatch_warnings.append(f"section wire {wire_i} area too small, hatch path excluded")
                        continue
                    wire_items.append({"wire":wire, "face":face, "area":area, "parent":None, "depth":0})
                except Exception as ex:
                    hatch_warnings.append(f"section wire {wire_i} face failed: {ex}")
                    wire_face_failed = True
            if wire_face_failed: wire_items = []
            for child_i, child in enumerate(wire_items):
                containers = []
                test_points = [vertex.toTuple() for vertex in child["wire"].Vertices()]
                for parent_i, parent in enumerate(wire_items):
                    if parent_i == child_i or parent["area"] <= child["area"]: continue
                    state = None
                    for point in test_points:
                        this_state = BRepClass_FaceClassifier(parent["face"].wrapped, gp_Pnt(*point), self.clean_eta).State()
                        if this_state != TopAbs_ON:
                            state = this_state
                            break
                    if state == TopAbs_IN: containers.append(parent_i)
                if containers: child["parent"] = min(containers, key=lambda index:wire_items[index]["area"])
            for item_i, item in enumerate(wire_items):
                parent_i = item["parent"]
                visited = {item_i}
                while parent_i is not None:
                    if parent_i in visited:
                        hatch_warnings.append(f"section wire {item_i} nesting cycle, hatch skipped")
                        item["depth"] = -1
                        break
                    visited.add(parent_i)
                    item["depth"] += 1
                    parent_i = wire_items[parent_i]["parent"]
            for item_i, item in enumerate(wire_items):
                if item["depth"] < 0 or item["depth"] % 2: continue
                try:
                    hole_wires = [child["wire"] for child in wire_items if child["parent"] == item_i]
                    face = cq.Face.makeFromWires(item["wire"], hole_wires)
                    outer = self._wire_2_hatch_edges(item["wire"], plane)
                    holes = [self._wire_2_hatch_edges(wire, plane) for wire in hole_wires]
                    cut_faces.append({"outer":outer, "holes":holes, "area":abs(float(face.Area())), "depth":item["depth"]})
                except Exception as ex:
                    hatch_warnings.append(f"section material face {item_i} hatch path failed: {ex}")
            if not cut_faces: hatch_warnings.append("section material face not found, hatch skipped")
        cut_keys = {self._prim_key(item) for item in cut if self._prim_key(item) is not None}
        for group_name in ("visible", "hidden", "tan"):
            image[group_name] = [item for item in image[group_name] if self._prim_key(item) not in cut_keys or self._prim_key(item) is None]
        bbox = self._cal_image_bbox({"visible":image["visible"] + cut, "hidden":image["hidden"], "tan":image["tan"]})
        source_names = ("front", "right", "top", "back", "left", "bottom")
        source_name = max(source_names, key=lambda name:float(np.dot(look_source, np.array(VIEW_DIRECTION[name]["N"], dtype=float))))
        up_source = np.cross(look_source, x_source)
        centerlines = []
        for item in self.translater.info.get("centerline_raw_pts", []):
            if not isinstance(item, dict): continue
            p1 = item.get("p1")
            p2 = item.get("p2")
            if p1 is None or p2 is None: continue
            if item.get("cen_type") == "十字":
                dir_n = item.get("dir_n")
                if dir_n is None or cal_collinear(dir_n, look_source) is None: continue
            points_2d = []
            for point in (p1, p2):
                point_source = np.array(point, dtype=float) - origin_source
                points_2d.append((float(np.dot(point_source, x_source)), float(np.dot(point_source, up_source))))
            if float(np.linalg.norm(np.array(points_2d[1]) - np.array(points_2d[0]))) < 1e-6: continue
            centerlines.append({"cen_type":item.get("cen_type"), "p1":points_2d[0], "p2":points_2d[1]})
        return {"visible":image["visible"], "hidden":image["hidden"], "tan":image["tan"], "cut":cut, "cut_faces":cut_faces, "hatch_warnings":hatch_warnings, "centerlines":centerlines, "bbox":bbox, "label":f"SECTION {setting['name']}", "N":tuple(look_source.tolist()), "U":tuple(up_source.tolist()), "R":tuple(x_source.tolist()), "is_iso":False, "is_section":True, "source_name":source_name, "look_from":look_from, "base_view":setting["base_view"]}
    def _wire_2_hatch_edges(self, wire, plane):
        if not wire.IsClosed(): raise ValueError("wire is not closed")
        edges = []
        for ent in self._wire_2_dxf_entities(wire, plane):
            ent_type = ent.dxftype()
            if ent_type == "LINE":
                edges.append({"type":"LINE", "p1":(float(ent.dxf.start[0]), float(ent.dxf.start[1])), "p2":(float(ent.dxf.end[0]), float(ent.dxf.end[1]))})
            elif ent_type == "ARC":
                edges.append({"type":"ARC", "c":(float(ent.dxf.center[0]), float(ent.dxf.center[1])), "r":float(ent.dxf.radius), "a1":float(ent.dxf.start_angle), "a2":float(ent.dxf.end_angle)})
            elif ent_type == "CIRCLE":
                edges.append({"type":"CIRCLE", "c":(float(ent.dxf.center[0]), float(ent.dxf.center[1])), "r":float(ent.dxf.radius)})
            elif ent_type == "ELLIPSE":
                edges.append({"type":"ELLIPSE", "c":(float(ent.dxf.center[0]), float(ent.dxf.center[1])), "major_axis":(float(ent.dxf.major_axis[0]), float(ent.dxf.major_axis[1])), "ratio":float(ent.dxf.ratio), "start_param":float(ent.dxf.start_param), "end_param":float(ent.dxf.end_param)})
            elif ent_type == "SPLINE":
                control_points = [(float(point[0]), float(point[1])) for point in ent.control_points]
                fit_points = [(float(point[0]), float(point[1])) for point in ent.fit_points]
                raw_weights = ent.weights() if callable(ent.weights) else ent.weights
                raw_knots = ent.knots() if callable(ent.knots) else ent.knots
                weights = [float(value) for value in raw_weights]
                edges.append({"type":"SPLINE", "control_points":control_points, "fit_points":fit_points, "knot_values":[float(value) for value in raw_knots], "weights":weights if weights else None, "degree":int(ent.dxf.degree), "periodic":1 if int(ent.dxf.flags) & 2 else 0})
            else:
                raise ValueError(f"unsupported hatch edge: {ent_type}")
        if not edges: raise ValueError("wire has no hatch edge")
        return edges
    def _wire_2_dxf_entities(self, wire, plane):
        entities = []
        for edge in wire.Edges():
            temp_doc = DxfDocument()
            try:
                temp_doc.add_shape(cq.Workplane(plane).newObject([edge]), "0")
            except Exception:
                temp_doc = DxfDocument()
                temp_doc.add_shape(cq.Workplane(plane).newObject([edge.toNURBS()]), "0")
            entities += list(temp_doc.document.modelspace())
        if not entities: raise ValueError("wire has no DXF edge")
        return entities
    def _init_view_images(self,):
        self.view_image_cache = {}
        for source_name in VIEW_DIRECTION:
            self.view_image_cache[source_name] = self._build_view_image(source_name)
        return self.view_image_cache
    def _build_view_image(self, source_name):
        cache_item = self.translater.get_hlr(source_name)
        image = {}
        for group_name in ("visible", "hidden", "tan"):
            edges = cache_item[group_name]
            if not edges:
                image[group_name] = []
                continue
            tmp_doc = DxfDocument()
            wp = cq.Workplane("XY").newObject(list(edges))
            tmp_doc.add_shape(wp, "0")
            image[group_name] = self._collect_primitives(tmp_doc.document.modelspace())
        image = self._clean(image)
        image["bbox"] = self._cal_image_bbox(image)
        return image
    def _collect_primitives(self, msp):
        items = []
        for ent in msp:
            ent_type = ent.dxftype()
            if ent_type == "LINE":
                items.append({"type":"LINE", "p1":(float(ent.dxf.start[0]), float(ent.dxf.start[1])), "p2":(float(ent.dxf.end[0]), float(ent.dxf.end[1]))})
            elif ent_type == "ARC":
                items.append({"type":"ARC", "c":(float(ent.dxf.center[0]), float(ent.dxf.center[1])), "r":float(ent.dxf.radius), "a1":float(ent.dxf.start_angle) % 360.0, "a2":float(ent.dxf.end_angle) % 360.0})
            elif ent_type == "CIRCLE":
                items.append({"type":"CIRCLE", "c":(float(ent.dxf.center[0]), float(ent.dxf.center[1])), "r":float(ent.dxf.radius)})
            else:
                prim = self._spline_2_prim(ent) if ent_type == "SPLINE" else None
                items.append(prim if prim is not None else {"type":"OTHER", "ent":ent})
        return items
    def _sample_ent(self, ent, eta):
        try:
            raw = [(float(p[0]), float(p[1])) for p in ent.flattening(eta)]
        except:
            return []
        pts = []
        for p in raw:
            if pts and abs(p[0] - pts[-1][0]) < self.clean_eta and abs(p[1] - pts[-1][1]) < self.clean_eta: continue
            pts.append(p)
        return pts
    def _fit_line(self, pts, tol):
        if len(pts) < 2: return None
        p1 = pts[0]
        p2 = pts[-1]
        dx = p2[0] - p1[0]
        dy = p2[1] - p1[1]
        length = (dx * dx + dy * dy) ** 0.5
        if length < self.clean_eta: return None
        ux = dx / length
        uy = dy / length
        for p in pts:
            if abs(-(p[0] - p1[0]) * uy + (p[1] - p1[1]) * ux) > tol: return None
        return {"type":"LINE", "p1":p1, "p2":p2}
    def _fit_circle(self, pts, tol):
        if len(pts) < 4: return None
        arr = np.array(pts, dtype=float)
        x = arr[:, 0]
        y = arr[:, 1]
        if math.hypot(float(np.ptp(x)), float(np.ptp(y))) < tol: return None
        singular_values = np.linalg.svd(arr - np.mean(arr, axis=0), compute_uv=False)
        if len(singular_values) < 2 or singular_values[1] < tol: return None
        a = np.column_stack([x, y, np.ones(len(arr))])
        b = x * x + y * y
        try:
            sol = np.linalg.lstsq(a, b, rcond=None)[0]
        except:
            return None
        cx = float(sol[0]) / 2
        cy = float(sol[1]) / 2
        val = float(sol[2]) + cx * cx + cy * cy
        if val <= 0: return None
        r = val ** 0.5
        if float(np.max(np.abs(np.hypot(x - cx, y - cy) - r))) > tol: return None
        return {"type":"CIRCLE", "c":(cx, cy), "r":r}
    def _spline_2_prim(self, ent):
        tol = self.spline_fit_tol
        pts = self._sample_ent(ent, tol)
        if len(pts) < 2: return None
        p1 = pts[0]
        p2 = pts[-1]
        if ((p2[0] - p1[0]) ** 2 + (p2[1] - p1[1]) ** 2) ** 0.5 < tol:
            return self._fit_circle(pts, tol)
        return self._fit_line(pts, tol)
    def _prim_key(self, item):
        d = self.pos_digits
        a = self.angle_digits
        if item["type"] == "LINE":
            k1 = (round(item["p1"][0], d), round(item["p1"][1], d))
            k2 = (round(item["p2"][0], d), round(item["p2"][1], d))
            if k2 < k1: k1, k2 = k2, k1
            return f"LINE|{k1[0]}|{k1[1]}|{k2[0]}|{k2[1]}"
        if item["type"] == "ARC":
            return f"ARC|{round(item['c'][0], d)}|{round(item['c'][1], d)}|{round(item['r'], d)}|{round(item['a1'], a)}|{round(item['a2'], a)}"
        if item["type"] == "CIRCLE":
            return f"CIRCLE|{round(item['c'][0], d)}|{round(item['c'][1], d)}|{round(item['r'], d)}"
        return None
    def _clean(self, image):
        ret = {}
        used_keys = set()
        for group_name in ("visible", "tan", "hidden"):
            items = []
            for item in image[group_name]:
                key = self._prim_key(item)
                if key is None:
                    items.append(item)
                    continue
                if key in used_keys: continue
                used_keys.add(key)
                items.append(item)
            ret[group_name] = self._merge_lines(items)
        return ret
    def _line_feat(self, p1, p2):
        dx = p2[0] - p1[0]
        dy = p2[1] - p1[1]
        length = (dx * dx + dy * dy) ** 0.5
        if length < self.clean_eta: return None
        angle = math.degrees(math.atan2(dy, dx)) % 180.0
        rad = math.radians(angle)
        ux = math.cos(rad)
        uy = math.sin(rad)
        offset = p1[0] * (-uy) + p1[1] * ux
        return {"angle":angle, "ux":ux, "uy":uy, "offset":offset}
    def _merge_lines(self, items):
        clusters = []
        others = []
        for item in items:
            if item["type"] != "LINE":
                others.append(item)
                continue
            feat = self._line_feat(item["p1"], item["p2"])
            if feat is None: continue
            mx = (item["p1"][0] + item["p2"][0]) / 2
            my = (item["p1"][1] + item["p2"][1]) / 2
            hit = None
            for cluster in clusters:
                da = abs(cluster["angle"] - feat["angle"])
                da = min(da, 180.0 - da)
                if da > self.line_merge_angle_tol: continue
                off = mx * (-cluster["uy"]) + my * cluster["ux"]
                if abs(off - cluster["offset"]) > self.line_merge_dist_tol: continue
                hit = cluster
                break
            if hit is None:
                hit = {"angle":feat["angle"], "ux":feat["ux"], "uy":feat["uy"], "offset":feat["offset"], "segments":[]}
                clusters.append(hit)
            t1 = item["p1"][0] * hit["ux"] + item["p1"][1] * hit["uy"]
            t2 = item["p2"][0] * hit["ux"] + item["p2"][1] * hit["uy"]
            if t1 > t2: t1, t2 = t2, t1
            hit["segments"].append([t1, t2])
        ret = []
        for cluster in clusters:
            ux = cluster["ux"]
            uy = cluster["uy"]
            ox = -uy * cluster["offset"]
            oy = ux * cluster["offset"]
            segments = sorted(cluster["segments"], key=lambda seg: seg[0])
            cur_t1, cur_t2 = segments[0]
            merged = []
            for seg in segments[1:]:
                if seg[0] <= cur_t2 + self.line_merge_gap_tol:
                    cur_t2 = max(cur_t2, seg[1])
                    continue
                merged.append([cur_t1, cur_t2])
                cur_t1, cur_t2 = seg
            merged.append([cur_t1, cur_t2])
            for seg in merged:
                ret.append({"type":"LINE", "p1":(ox + ux * seg[0], oy + uy * seg[0]), "p2":(ox + ux * seg[1], oy + uy * seg[1])})
        return ret + others
    def _rot90_pt(self, p, k):
        x, y = float(p[0]), float(p[1])
        if k == 1: return (-y, x)
        if k == 2: return (-x, -y)
        if k == 3: return (y, -x)
        return (x, y)
    def _rot90_image(self, image, k):
        k = int(k) % 4
        if k == 0: return image
        m = Matrix44.z_rotate(math.radians(90.0 * k))
        ret = {}
        for group_name in ("visible", "hidden", "tan"):
            items = []
            for item in image[group_name]:
                if item["type"] == "LINE":
                    items.append({"type":"LINE", "p1":self._rot90_pt(item["p1"], k), "p2":self._rot90_pt(item["p2"], k)})
                elif item["type"] == "ARC":
                    items.append({"type":"ARC", "c":self._rot90_pt(item["c"], k), "r":item["r"], "a1":(item["a1"] + 90.0 * k) % 360.0, "a2":(item["a2"] + 90.0 * k) % 360.0})
                elif item["type"] == "CIRCLE":
                    items.append({"type":"CIRCLE", "c":self._rot90_pt(item["c"], k), "r":item["r"]})
                else:
                    new_ent = item["ent"].copy()
                    new_ent.transform(m)
                    items.append({"type":"OTHER", "ent":new_ent})
            ret[group_name] = items
        ret["bbox"] = self._cal_image_bbox(ret)
        return ret
    def _arc_span(self, a1, a2):
        span = (a2 - a1) % 360.0
        if span == 0.0: span = 360.0
        return span
    def _arc_has_angle(self, a1, a2, a):
        return ((a - a1) % 360.0) <= self._arc_span(a1, a2)
    def _cal_image_bbox(self, image):
        xs = []
        ys = []
        for group_name in ("visible", "hidden", "tan"):
            for item in image[group_name]:
                if item["type"] == "LINE":
                    xs += [item["p1"][0], item["p2"][0]]
                    ys += [item["p1"][1], item["p2"][1]]
                elif item["type"] == "CIRCLE":
                    cx, cy = item["c"]
                    r = item["r"]
                    xs += [cx - r, cx + r]
                    ys += [cy - r, cy + r]
                elif item["type"] == "ARC":
                    cx, cy = item["c"]
                    r = item["r"]
                    a1 = item["a1"]
                    a2 = item["a2"]
                    for a in (a1, a2):
                        rad = math.radians(a)
                        xs.append(cx + r * math.cos(rad))
                        ys.append(cy + r * math.sin(rad))
                    if self._arc_has_angle(a1, a2, 0.0): xs.append(cx + r)
                    if self._arc_has_angle(a1, a2, 180.0): xs.append(cx - r)
                    if self._arc_has_angle(a1, a2, 90.0): ys.append(cy + r)
                    if self._arc_has_angle(a1, a2, 270.0): ys.append(cy - r)
                else:
                    ent = item["ent"]
                    try:
                        for p in ent.flattening(0.2):
                            xs.append(float(p[0]))
                            ys.append(float(p[1]))
                    except:
                        pass
        if not xs or not ys: return None
        return (min(xs), max(xs), min(ys), max(ys))

class DXF_Drawer:
    def __init__(self, notation_text_style="ROMANS_CHINA", notation_font="romans.shx", notation_bigfont="chineset.shx", notation_dimstyle="CAD_HELPER_DIM"):
        self.notation_text_style = notation_text_style
        self.notation_font = notation_font
        self.notation_bigfont = notation_bigfont
        self.notation_dimstyle = notation_dimstyle
        self.dxf_doc = None
        self.doc = None
        self.draw_order_handles = {"hatch": [], "hidden": [], "tan": [], "visible": []}
        self._init_dxf_document()
    def _init_dxf_document(self,):
        doc = DxfDocument(setup=["linetypes"])
        for name, item in DXF_LINETYPE_ITEMS.items():
            if name not in doc.document.linetypes:
                doc.document.linetypes.add(name, **item)
            else:
                linetype = doc.document.linetypes.get(name)
                try:
                    linetype.dxf.description = item.get("description", linetype.dxf.get("description", ""))
                    linetype.setup_pattern(item["pattern"])
                except:
                    pass
        for layer_name, layer_item in DXF_LAYER_ITEMS.items():
            layer_kw = {"color": layer_item["color"]}
            if layer_item.get("linetype") is not None:
                layer_kw["linetype"] = layer_item["linetype"]
            if layer_name not in doc.document.layers:
                doc.add_layer(layer_name, **layer_kw)
            layer = doc.document.layers.get(layer_name)
            layer.dxf.color = layer_item["color"]
            layer.dxf.linetype = layer_item.get("linetype", "CONTINUOUS")
            layer.dxf.lineweight = layer_item["lineweight"]
        style_kw = {"font":self.notation_font}
        if self.notation_bigfont is not None: style_kw["bigfont"] = self.notation_bigfont
        if self.notation_text_style not in doc.document.styles:
            doc.document.styles.new(self.notation_text_style, dxfattribs=style_kw)
        else:
            text_style = doc.document.styles.get(self.notation_text_style)
            text_style.dxf.font = self.notation_font
            if self.notation_bigfont is not None: text_style.dxf.bigfont = self.notation_bigfont
        dimstyle_kw = {"dimtxsty":self.notation_text_style, "dimtxt":3.0, "dimasz":3.0, "dimblk":"", "dimblk1":"", "dimblk2":"", "dimldrblk":""}
        if self.notation_dimstyle not in doc.document.dimstyles:
            doc.document.dimstyles.new(self.notation_dimstyle, dxfattribs=dimstyle_kw)
        else:
            dimstyle = doc.document.dimstyles.get(self.notation_dimstyle)
            for key, val in dimstyle_kw.items():
                setattr(dimstyle.dxf, key, val)
        self.dxf_doc = doc
        self.doc = doc.document
        return self.doc
    def check_layer(self, layer):
        if layer not in self.doc.layers:
            raise ValueError(f"layer not found: {layer}")
        return layer
    def _dim_override(self, text_h, arrow_h, dim_scale=1.0):
        return {"dimtxt": text_h, "dimasz": arrow_h, "dimscale": float(dim_scale), "dimtxsty": self.notation_text_style}
    def add_line(self, p1, p2, layer):
        self.check_layer(layer)
        p1 = tuple(float(x) for x in p1)
        p2 = tuple(float(x) for x in p2)
        line = self.doc.modelspace().add_line(p1, p2, dxfattribs={"layer": layer})
        self.set_auto_linetype_scale(line, layer)
        return line
    def add_arc(self, center, radius, start_angle, end_angle, layer):
        self.check_layer(layer)
        arc = self.doc.modelspace().add_arc(center=(float(center[0]), float(center[1])), radius=float(radius), start_angle=float(start_angle), end_angle=float(end_angle), dxfattribs={"layer": layer})
        self.set_auto_linetype_scale(arc, layer)
        return arc
    def add_circle(self, center, radius, layer):
        self.check_layer(layer)
        circle = self.doc.modelspace().add_circle(center=(float(center[0]), float(center[1])), radius=float(radius), dxfattribs={"layer": layer})
        self.set_auto_linetype_scale(circle, layer)
        return circle
    def add_mtext(self, words, xy, layer, text_h=3.0, attachment_point=7, width=None):
        self.check_layer(layer)
        mtext = self.doc.modelspace().add_mtext(scale_cjk_text(words), dxfattribs={"layer": layer, "style": self.notation_text_style})
        mtext.dxf.char_height = float(text_h)
        mtext.set_location((float(xy[0]), float(xy[1])), attachment_point=attachment_point)
        if width is not None: mtext.dxf.width = float(width)
        return mtext
    def add_linear_dim(self, p1, p2, location, angle=0, layer="DIM", text_h=3.0, arrow_h=3.0, text=None, dim_scale=1.0):
        self.check_layer(layer)
        dim = self.doc.modelspace().add_linear_dim(base=location, p1=p1, p2=p2, angle=angle, text="<>" if text is None else scale_cjk_text(text), dimstyle=self.notation_dimstyle, override=self._dim_override(text_h, arrow_h, dim_scale), dxfattribs={"layer": layer})
        dim.render()
        return dim
    def add_radius_dim(self, center, p1, angle=45, layer="DIM", text=None, text_h=3.0, arrow_h=3.0, dim_scale=1.0):
        self.check_layer(layer)
        dim = self.doc.modelspace().add_radius_dim(center=center, mpoint=p1, angle=angle, text="<>" if text is None else scale_cjk_text(text), dimstyle=self.notation_dimstyle, override=self._dim_override(text_h, arrow_h, dim_scale), dxfattribs={"layer": layer})
        dim.render()
        return dim
    def add_diameter_dim(self, center, p1, angle=45, layer="DIM", text=None, text_h=3.0, arrow_h=3.0, dim_scale=1.0):
        self.check_layer(layer)
        dim = self.doc.modelspace().add_diameter_dim(center=center, mpoint=p1, angle=angle, text="<>" if text is None else scale_cjk_text(text), dimstyle=self.notation_dimstyle, override=self._dim_override(text_h, arrow_h, dim_scale), dxfattribs={"layer": layer})
        dim.render()
        return dim
    def add_ordinate_dim(self, feature_location, leader_endpoint, orientation="X", origin=(0, 0), text=None, layer="DIM", text_h=3.0, arrow_h=3.0, dim_scale=1.0):
        self.check_layer(layer)
        feature_location = (float(feature_location[0]), float(feature_location[1]))
        offset = (float(leader_endpoint[0]) - feature_location[0], float(leader_endpoint[1]) - feature_location[1])
        override = self._dim_override(text_h, arrow_h, dim_scale)
        if orientation.upper() == "X":
            dim = self.doc.modelspace().add_ordinate_x_dim(feature_location=feature_location, offset=offset, origin=origin, text="<>" if text is None else scale_cjk_text(text), dimstyle=self.notation_dimstyle, override=override, dxfattribs={"layer": layer})
        else:
            dim = self.doc.modelspace().add_ordinate_y_dim(feature_location=feature_location, offset=offset, origin=origin, text="<>" if text is None else scale_cjk_text(text), dimstyle=self.notation_dimstyle, override=override, dxfattribs={"layer": layer})
        dim.render()
        return dim
    def add_qleader(self, xy, txy, word1, word2, layer, text_h=3.0, arrow_h=3.0):
        self.check_layer(layer)
        x, y = float(xy[0]), float(xy[1])
        tx, ty = float(txy[0]), float(txy[1])
        h = float(text_h)
        word1 = "" if word1 is None else str(word1)
        word2 = "" if word2 is None else str(word2)
        lines = [word1] if word2 == "" else [word1, word2]
        line_len = max(h * 4, max(len(item) for item in lines) * h)
        if x <= tx:
            text_x = tx
            end_x = tx + line_len
        else:
            end_x = tx - line_len
            text_x = end_x
        if word2 == "":
            self.add_mtext(word1, (text_x, ty + h * 0.5), layer, text_h=h, attachment_point=7, width=line_len)
        else:
            self.add_mtext(word1, (text_x, ty + h * 0.25), layer, text_h=h, attachment_point=7, width=line_len)
            self.add_mtext(word2, (text_x, ty - h * 0.25), layer, text_h=h, attachment_point=1, width=line_len)
        leader = self.doc.modelspace().add_leader(vertices=[Vec2(x, y), Vec2(tx, ty), Vec2(end_x, ty)], dimstyle=self.notation_dimstyle, override=self._dim_override(h, arrow_h), dxfattribs={"layer": layer})
        return leader
    def add_hatch_faces(self, cut_faces, dx=0, dy=0, layer="HAT", pattern_name="ANSI31", angle=0, scale=1.0, min_area=1e-6):
        self.check_layer(layer)
        scale = float(scale)
        if scale <= 0: raise ValueError("hatch scale must be positive")
        msp = self.doc.modelspace()
        report = {"count":0, "skipped":[]}
        for face_i, item in enumerate(cut_faces):
            if float(item.get("area", 0)) <= float(min_area):
                report["skipped"].append(f"section face {face_i} area too small")
                continue
            hatch = None
            try:
                hatch = msp.add_hatch(dxfattribs={"layer":layer})
                hatch.set_pattern_fill(str(pattern_name), color=256, angle=float(angle), scale=scale, style=0)
                for path_i, edge_items in enumerate([item["outer"]] + item.get("holes", [])):
                    if not edge_items: raise ValueError(f"empty hatch path {path_i}")
                    path = hatch.paths.add_edge_path(flags=1 if path_i == 0 else 16)
                    for edge in edge_items:
                        edge_type = edge["type"]
                        if edge_type == "LINE":
                            path.add_line((edge["p1"][0] + dx, edge["p1"][1] + dy), (edge["p2"][0] + dx, edge["p2"][1] + dy))
                        elif edge_type == "ARC":
                            path.add_arc((edge["c"][0] + dx, edge["c"][1] + dy), edge["r"], edge["a1"], edge["a2"], True)
                        elif edge_type == "CIRCLE":
                            path.add_arc((edge["c"][0] + dx, edge["c"][1] + dy), edge["r"], 0, 360, True)
                        elif edge_type == "ELLIPSE":
                            path.add_ellipse((edge["c"][0] + dx, edge["c"][1] + dy), edge["major_axis"], edge["ratio"], math.degrees(edge["start_param"]), math.degrees(edge["end_param"]), True)
                        elif edge_type == "SPLINE":
                            control_points = [(point[0] + dx, point[1] + dy) for point in edge["control_points"]]
                            fit_points = [(point[0] + dx, point[1] + dy) for point in edge["fit_points"]]
                            path.add_spline(fit_points=fit_points if fit_points else None, control_points=control_points if control_points else None, knot_values=edge["knot_values"], weights=edge["weights"], degree=edge["degree"], periodic=edge["periodic"])
                        else:
                            raise ValueError(f"unsupported hatch edge: {edge_type}")
                if hasattr(hatch.dxf, "handle"): self.draw_order_handles["hatch"].append(hatch.dxf.handle)
                report["count"] += 1
            except Exception as ex:
                if hatch is not None and hatch.is_alive: msp.delete_entity(hatch)
                report["skipped"].append(f"section face {face_i} hatch failed: {ex}")
        return report
    def draw_view_edges(self, items, dx, dy, layer, group_name="visible", scale=1.0):
        msp = self.doc.modelspace()
        count = 0
        scale = float(scale)
        for item in items:
            before_i = len(msp)
            if item["type"] == "LINE":
                self.add_line((item["p1"][0] * scale + dx, item["p1"][1] * scale + dy), (item["p2"][0] * scale + dx, item["p2"][1] * scale + dy), layer)
            elif item["type"] == "ARC":
                self.add_arc((item["c"][0] * scale + dx, item["c"][1] * scale + dy), item["r"] * scale, item["a1"], item["a2"], layer)
            elif item["type"] == "CIRCLE":
                self.add_circle((item["c"][0] * scale + dx, item["c"][1] * scale + dy), item["r"] * scale, layer)
            else:
                new_ent = item["ent"].copy()
                if abs(scale - 1.0) > 1e-12: new_ent.transform(Matrix44.scale(scale, scale, 1))
                new_ent.translate(dx, dy, 0)
                new_ent.dxf.layer = layer
                msp.add_entity(new_ent)
            for ent in list(msp)[before_i:]:
                if hasattr(ent.dxf, "handle"):
                    self.draw_order_handles[group_name].append(ent.dxf.handle)
                self.set_auto_linetype_scale(ent, layer)
            count += 1
        return count
    def apply_redraw_order(self,):
        ordered_handles = self.draw_order_handles["hatch"] + self.draw_order_handles["hidden"] + self.draw_order_handles["tan"] + self.draw_order_handles["visible"]
        if not ordered_handles: return 0
        sort_handles = sorted(ordered_handles, key=lambda x: int(x, 16))
        self.doc.modelspace().set_redraw_order(zip(ordered_handles, sort_handles))
        return len(ordered_handles)
    def set_auto_linetype_scale(self, ent=None, layer=None):
        if ent is None:
            if self.doc is None: return 0
            count = 0
            for this_ent in self.doc.modelspace():
                if self.set_auto_linetype_scale(this_ent) is not None:
                    count += 1
            return count
        layer = layer if layer is not None else ent.dxf.get("layer", None)
        ltscale_key = {"AUTO_CEN": "cen", "HID": "hid"}.get(layer)
        if ltscale_key is None: return None
        if not ent.dxf.is_supported("ltscale"): return None
        ltscale_item = getattr(self, "hyp", CAD_HELPER_HYP)["線型比例"][ltscale_key]
        gamma = float(ltscale_item["gamma"])
        beta = float(ltscale_item["beta"])
        ent_type = ent.dxftype()
        length = None
        if ent_type == "LINE":
            p1 = ent.dxf.start
            p2 = ent.dxf.end
            length = sum((float(p2[i]) - float(p1[i])) ** 2 for i in range(3)) ** 0.5
        elif ent_type == "CIRCLE":
            length = 2 * math.pi * float(ent.dxf.radius)
        elif ent_type == "ARC":
            angle = (float(ent.dxf.end_angle) - float(ent.dxf.start_angle)) % 360
            length = 2 * math.pi * float(ent.dxf.radius) * angle / 360
        else:
            try:
                pts = list(ent.flattening(0.2))
                if len(pts) > 1:
                    length = sum(sum((float(p2[i]) - float(p1[i])) ** 2 for i in range(min(len(p1), len(p2)))) ** 0.5 for p1, p2 in zip(pts[:-1], pts[1:]))
            except:
                pass
        if length is None or length <= 0: return None
        ent.dxf.ltscale = max(gamma * (length ** beta), 1e-3)
        return ent.dxf.ltscale
    def get_dxf(self,):
        return self.doc
    def add_dxf(self, dxf, position=(0, 0)):
        if isinstance(dxf, CAD_Helper): dxf = dxf.get_dxf()
        if hasattr(dxf, "document"): dxf = dxf.document
        src_msp = dxf.modelspace()
        try:
            source_entities = list(src_msp.entities_in_redraw_order())
        except:
            source_entities = list(src_msp)
        source_bbox = bbox.extents(source_entities, fast=True)
        dx = float(position[0])
        dy = float(position[1])
        if source_bbox.has_data:
            dx -= float(source_bbox.extmin.x)
            dy -= float(source_bbox.extmin.y)
        importer = Importer(dxf, self.doc)
        try:
            importer.import_tables("*")
            block_names = [block.name for block in dxf.blocks if not block.name.lower().startswith("*model") and not block.name.lower().startswith("*paper")]
            importer.import_blocks(block_names, rename=False)
            importer.finalize()
        except:
            pass
        msp = self.doc.modelspace()
        count = 0
        redraw_handles = []
        for ent in source_entities:
            try:
                new_ent = ent.copy()
                if dx or dy: new_ent.translate(dx, dy, 0)
                msp.add_entity(new_ent)
                if hasattr(new_ent.dxf, "handle"): redraw_handles.append(new_ent.dxf.handle)
                count += 1
            except:
                pass
        if redraw_handles:
            sort_handles = sorted(redraw_handles, key=lambda x: int(x, 16))
            msp.set_redraw_order(zip(redraw_handles, sort_handles))
        return count
    def save(self, fpath):
        self.doc.saveas(fpath)
        return fpath
    def _fix_dim_block_layers(self):
        for ent in self.doc.modelspace():
            if ent.dxftype() != "DIMENSION": continue
            dim_layer = ent.dxf.layer
            layer_color = DXF_LAYER_ITEMS.get(dim_layer, {}).get("color", 7)
            block_name = ent.dxf.get("geometry", None)
            if block_name is None or block_name not in self.doc.blocks: continue
            for block_ent in self.doc.blocks.get(block_name):
                block_ent.dxf.layer = dim_layer
                block_ent.dxf.color = layer_color
        return self.doc
    def get_quick_view_img(self, dpi=100, bg="#0a0a0a", lineweight_scaling=6.0, text_scale=3):
        self._fix_dim_block_layers()
        preview_font = "C:/Windows/Fonts/msjh.ttc"
        style_states = []
        text_states = []
        for style in self.doc.styles:
            has_bigfont = style.dxf.hasattr("bigfont")
            style_states.append((style, style.dxf.font, has_bigfont, style.dxf.bigfont if has_bigfont else None))
            style.dxf.font = preview_font
            if has_bigfont: style.dxf.discard("bigfont")
        for ent in self.doc.modelspace():
            ent_type = ent.dxftype()
            if ent_type == "MTEXT":
                text_states.append((ent, "char_height", float(ent.dxf.char_height)))
                ent.dxf.char_height = float(ent.dxf.char_height) * text_scale
            elif ent_type == "TEXT":
                text_states.append((ent, "height", float(ent.dxf.height)))
                ent.dxf.height = float(ent.dxf.height) * text_scale
        for block in self.doc.blocks:
            if not block.name.lower().startswith("*d"): continue
            for ent in block:
                ent_type = ent.dxftype()
                if ent_type == "MTEXT":
                    text_states.append((ent, "char_height", float(ent.dxf.char_height)))
                    ent.dxf.char_height = float(ent.dxf.char_height) * text_scale
                elif ent_type == "TEXT":
                    text_states.append((ent, "height", float(ent.dxf.height)))
                    ent.dxf.height = float(ent.dxf.height) * text_scale
        try:
            msp = self.doc.modelspace()
            ctx = RenderContext(self.doc)
            cfg = Configuration(line_policy=LinePolicy.ACCURATE, lineweight_policy=LineweightPolicy.ABSOLUTE, lineweight_scaling=lineweight_scaling)
            msp_props = LayoutProperties.from_layout(msp)
            msp_props.set_colors(bg)
            backend = svg.SVGBackend()
            Frontend(ctx, backend, config=cfg).draw_layout(msp, finalize=True, layout_properties=msp_props)
            page = layout.Page(0, 0)
            svg_str = backend.get_string(page)
            rules = dict(re.findall(r'\.(C\d+)\s*\{([^}]*)\}', svg_str))
            for cls, body in rules.items():
                attrs = []
                for key in ("stroke", "stroke-width", "fill"):
                    match = re.search(rf'\b{key}\s*:\s*([^;]+);', body)
                    if match: attrs.append(f'{key}="{match.group(1).strip()}"')
                svg_str = svg_str.replace(f'class="{cls}"', " ".join(attrs))
        finally:
            for ent, attr, value in text_states: setattr(ent.dxf, attr, value)
            for style, font, has_bigfont, bigfont in style_states:
                style.dxf.font = font
                if has_bigfont: style.dxf.bigfont = bigfont
                elif style.dxf.hasattr("bigfont"): style.dxf.discard("bigfont")
        svg_doc = fitz.open(stream=svg_str.encode("utf-8"), filetype="svg")
        try:
            fitz_doc = fitz.open("pdf", svg_doc.convert_to_pdf())
            try:
                fitz_page = fitz_doc[0]
                mat = fitz.Matrix(dpi / 72, dpi / 72)
                pix = fitz_page.get_pixmap(matrix=mat, colorspace=fitz.csRGB)
                img = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width, pix.n)
                if pix.n > 3: img = img[:, :, :3]
                return img[:, :, ::-1].copy()
            finally:
                fitz_doc.close()
        finally:
            svg_doc.close()

class CAD_Helper:
    #  ---------------  初始化與載入  ----------------
    def __init__(self, stp_fpath=None):
        self.stp_fpath = None
        self.translater = None
        self.projector = None
        self.drawer = None
        self.info = {}
        self.doc = None
        self.view_data = None
        self.view_payloads = {}
        self.proj_offset = {}
        self.notation_scale = 1.0
        self.notation_scale_name = None
        self.linear_dim_normal_counts = {}
        self.linear_dim_outer_items = {}
        self.geom_match_tol = 1e-3
        self.autodim_views = ("front", "right", "top")
        self.rotate_info = {"x": 0, "y": 0, "z": 0}
        self.section_settings = []
        self.section_view_data = {}
        self.hyp = copy.deepcopy(CAD_HELPER_HYP)
        if stp_fpath is not None:
            self.load(stp_fpath)
    def load(self, stp_fpath):
        if self.projector is not None: self.rotate_info = self.projector.rotate()["rotate_info"].copy()
        self.stp_fpath = stp_fpath
        self.translater = STEP_Translater(stp_fpath, self.hyp["滑槽偵測"])
        self.projector = View_Projector(self.translater)
        if any(self.rotate_info.values()): self.projector.rotate(**self.rotate_info)
        self.info = self.translater.info
        self.section_settings = []
        self.section_view_data = {}
        return self.translater.entities
    def refresh_feature_dims(self,):
        if self.translater is None: return self.info
        feature_keys = ("slot_dims", "fillet_dims", "cyn_dims", "rib_dims", "plane_dims", "face_claims", "dimed_faces")
        old_info = {key:(key in self.translater.info, copy.deepcopy(self.translater.info.get(key))) for key in feature_keys}
        old_slot_setting = copy.deepcopy(self.translater.slot_setting)
        try: self.translater.refresh_feature_dims(self.hyp["滑槽偵測"])
        except Exception:
            self.translater.slot_setting = old_slot_setting
            for key, (exists, value) in old_info.items():
                if exists: self.translater.info[key] = value
                else: self.translater.info.pop(key, None)
            self.info = self.translater.info
            raise
        self.info = self.translater.info
        self.view_payloads = {}
        return self.info
    @property
    def entities(self,):
        return self.translater.entities
    @property
    def rotation_matrix(self,):
        return self.projector.rotation_matrix
    @property
    def view_map_after_rotate(self,):
        return self.projector.view_map_after_rotate
    def get_dxf(self,):
        return self.doc
    #  ---------------  投影與座標工具  ----------------
    def _proj_2_view(self, pts, view_name="front"):
        pts_2d = self.projector.proj_pt(pts, view_name)
        return pts_2d + np.array(self.proj_offset[view_name], dtype=float)
    def _cal_view_circles(self, view_name):
        view_item = self.projector.get_view(view_name)
        dx, dy = self.proj_offset[view_name]
        ret = []
        for group_name in ("visible", "hidden"):
            for item in view_item[group_name]:
                if item["type"] not in ("CIRCLE", "ARC"): continue
                ret.append({"c":(item["c"][0] + float(dx), item["c"][1] + float(dy)), "r":float(item["r"]), "group":group_name})
        return ret
    def _cal_circle_back(self, circles, xy, r=None, tol=None):
        if tol is None: tol = self.geom_match_tol
        hits = []
        for circle in circles:
            if abs(circle["c"][0] - xy[0]) > tol: continue
            if abs(circle["c"][1] - xy[1]) > tol: continue
            if r is not None and abs(circle["r"] - r) > tol: continue
            hits.append(circle)
        if not hits: return None
        for circle in hits:
            if circle["group"] == "visible": return False
        return True

    #  ---------------  使用者設定  ----------------
    def rotate(self, x=None, y=None, z=None):
        if self.projector is None:
            for axis, value in (("x", x), ("y", y), ("z", z)):
                if value is not None: self.rotate_info[axis] += int(value)
            return {"rotate_info":self.rotate_info.copy(), "rotation_matrix":None, "view_map_after_rotate":{}}
        ret = self.projector.rotate(x, y, z)
        self.rotate_info = ret["rotate_info"].copy()
        return ret
    def set_section_view(self, direction=None, position=None, look_from=None, name=None, base_view="front"):
        if direction is None:
            self.section_settings = []
            self.section_view_data = {}
            return None
        if self.projector is None: raise ValueError("load STEP before set_section_view")
        if base_view != "front": raise ValueError("first section version only supports base_view='front'")
        if direction not in ("horizontal", "vertical"): raise ValueError("direction must be horizontal or vertical")
        valid_look = ("top", "bottom") if direction == "horizontal" else ("left", "right")
        if look_from not in valid_look: raise ValueError(f"look_from must be one of {valid_look} for {direction} section")
        try: position = float(position)
        except: raise ValueError("position must be a number measured from the front-view left or bottom edge")
        if not math.isfinite(position): raise ValueError("position must be finite")
        bbox = self.projector.get_view(base_view)["bbox"]
        axis_min, axis_max = (bbox[2], bbox[3]) if direction == "horizontal" else (bbox[0], bbox[1])
        tol = max(self.geom_match_tol, (axis_max - axis_min) * 1e-8)
        axis_length = axis_max - axis_min
        if position <= tol or position >= axis_length - tol: raise ValueError(f"position must be inside front-view relative range (0, {axis_length:g})")
        absolute_position = axis_min + position
        used_names = {item["name"] for item in self.section_settings}
        if name is None:
            name_index = 0
            while True:
                value = name_index
                letters = ""
                while value >= 0:
                    letters = f"{chr(65 + value % 26)}{letters}"
                    value = value // 26 - 1
                name = f"{letters}-{letters}"
                if name not in used_names: break
                name_index += 1
        else:
            name = str(name).strip()
            if not name: raise ValueError("section name cannot be empty")
            if name in used_names: raise ValueError(f"section name already exists: {name}")
        section_setting = {"name":name, "base_view":base_view, "direction":direction, "position":position, "absolute_position":absolute_position, "look_from":look_from, "rotate_info":{key:int(val) % 4 for key, val in self.projector.rotate_info.items()}, "rotation_matrix":tuple(tuple(float(val) for val in row) for row in self.projector.rotation_matrix)}
        ret = copy.deepcopy(section_setting)
        section_build_setting = copy.deepcopy(section_setting)
        section_build_setting["hatch_min_area"] = self.hyp["剖面圖"]["填充線"]["最小面積"]
        section_view = self.projector._build_section_view(section_build_setting)
        section_payload = {"section":{"centerlines":section_view["centerlines"]}}
        self._merge_centerlines(section_payload, gap=1.0)
        section_view["cen_lines"] = section_payload["section"]["cen_lines"]
        section_setting["view"] = section_view
        self.section_settings.append(section_setting)
        self.section_view_data = {}
        return ret
    def set_hidden(self, kw):
        for target_name, val in kw.items():
            self.hyp["隱藏線可見"][target_name] = bool(val)
        return self.hyp["隱藏線可見"].copy()
    def set_autodim_views(self, kw={"hor":"right", "ver":"top"}):
        if kw is None: kw = {}
        if isinstance(kw, (list, tuple)):
            view_names = list(kw)
            hor_list = [view_name for view_name in view_names if view_name in ("right", "left")]
            ver_list = [view_name for view_name in view_names if view_name in ("top", "bottom")]
            if view_names.count("front") != 1 or len(hor_list) != 1 or len(ver_list) != 1 or len(view_names) != 3:
                raise ValueError(f"autodim views must be front + one of right/left + one of top/bottom in priority order: {view_names}")
            self.autodim_views = tuple(view_names)
            return self.autodim_views
        for key in kw:
            if key not in ("hor", "ver"):
                raise ValueError(f"autodim view key must be hor or ver: {key}")
        hor = kw.get("hor", "right")
        ver = kw.get("ver", "top")
        if hor not in ("right", "left"):
            raise ValueError(f"hor view must be right or left: {hor}")
        if ver not in ("top", "bottom"):
            raise ValueError(f"ver view must be top or bottom: {ver}")
        view_names = ["front"]
        for view_name in (hor, ver):
            if view_name not in view_names: view_names.append(view_name)
        self.autodim_views = tuple(view_names)
        return self.autodim_views
    def set_view_notation_methods(self, kw=None, default=None, base=None, hor_alpha=None, ver_alpha=None):
        if kw is None: kw = {}
        if base is None: base = {}
        valid_view_names = ("front", "right", "left", "top", "bottom", "back")
        valid_methods = ("linear", "ordinate")
        valid_bases = ("left-bottom", "right-bottom", "left-up", "right-up")
        if default is not None:
            if default not in valid_methods:
                raise ValueError(f"notation method must be linear or ordinate: {default}")
            for view_name in valid_view_names:
                self.hyp["線性標注方法"][view_name] = default
        for view_name, method in kw.items():
            if view_name not in valid_view_names:
                raise ValueError(f"view_name must be rotated display view: {view_name}")
            if method not in valid_methods:
                raise ValueError(f"notation method must be linear or ordinate: {method}")
            self.hyp["線性標注方法"][view_name] = method
        for view_name, this_base in base.items():
            if view_name not in valid_view_names:
                raise ValueError(f"view_name must be rotated display view: {view_name}")
            if this_base not in valid_bases:
                raise ValueError(f"notation base must be one of {valid_bases}: {this_base}")
            self.hyp["標注基準參考"][view_name] = this_base
        if hor_alpha is not None:
            for view_name, val in hor_alpha.items():
                if view_name not in valid_view_names: raise ValueError(f"view_name must be rotated display view: {view_name}")
                self.hyp["尺寸靠邊權重"][view_name]["x"] = float(val)
        if ver_alpha is not None:
            for view_name, val in ver_alpha.items():
                if view_name not in valid_view_names: raise ValueError(f"view_name must be rotated display view: {view_name}")
                self.hyp["尺寸靠邊權重"][view_name]["y"] = float(val)
        return {"views":self.hyp["線性標注方法"].copy(), "base":self.hyp["標注基準參考"].copy()}

    #  ---------------  標註設定解析 (內部)  ----------------
    def _cal_notation_base(self, view_name):
        return self.hyp["標注基準參考"].get(view_name, "left-bottom")
    def _cal_notation_alpha(self, view_name, axis):
        return self.hyp["尺寸靠邊權重"][view_name]["x" if axis == "X" else "y"]

    #  ---------------  版面與比例  ----------------
    def layout_views(self,):
        if self.drawer is None:
            self.drawer = DXF_Drawer()
            self.drawer.hyp = self.hyp
            self.doc = self.drawer.doc
        view_order = ["iso_front", "top", "iso_back", "left", "front", "right", "bottom"]
        layout = {name:tuple(cell) for name, cell in self.hyp["視圖佈局網格"].items()}
        section_views = {}
        if self.section_settings:
            if self.hyp["剖面圖"].get("放置方式", "next_free") != "next_free": raise ValueError("section placement must be next_free")
            occupied = set(layout.values())
            for section_setting in self.section_settings:
                section_view = section_setting["view"]
                section_name = f"section_{section_setting['name']}"
                if section_name in layout or section_name in section_views: raise ValueError(f"section name already exists: {section_setting['name']}")
                base_cell = layout[section_setting["base_view"]]
                delta = {"top":(0, 1), "bottom":(0, -1), "left":(-1, 0), "right":(1, 0)}[section_setting["look_from"]]
                section_cell = (base_cell[0] + delta[0], base_cell[1] + delta[1])
                while section_cell in occupied: section_cell = (section_cell[0] + delta[0], section_cell[1] + delta[1])
                layout[section_name] = section_cell
                occupied.add(section_cell)
                view_order.append(section_name)
                section_views[section_name] = section_view
        min_col = min(int(cell[0]) for cell in layout.values())
        min_row = min(int(cell[1]) for cell in layout.values())
        layout = {name:(int(cell[0]) - min_col, int(cell[1]) - min_row) for name, cell in layout.items()}
        source_items = {}
        iso_scale = float(self.hyp["等角圖縮放"])
        if not math.isfinite(iso_scale) or iso_scale <= 0: raise ValueError("等角圖縮放 must be finite and greater than 0")
        for target_name in view_order:
            view_item = section_views[target_name] if target_name in section_views else self.projector.get_view(target_name)
            this_show_hidden = bool(self.hyp["剖面圖"]["顯示隱藏線"]) if target_name in section_views else False if view_item["is_iso"] else bool(self.hyp["隱藏線可見"][target_name])
            cut = view_item.get("cut", [])
            bbox_image = {"visible":view_item["visible"] + cut, "hidden":view_item["hidden"] if this_show_hidden else [], "tan":view_item["tan"]}
            bbox = self.projector._cal_image_bbox(bbox_image)
            if bbox is None:
                raise ValueError(f"{target_name} view no projection edge")
            xmin, xmax, ymin, ymax = bbox
            view_scale = iso_scale if view_item["is_iso"] else 1.0
            xmin, xmax, ymin, ymax = xmin * view_scale, xmax * view_scale, ymin * view_scale, ymax * view_scale
            source_items[target_name] = {"visible":view_item["visible"], "hidden":view_item["hidden"], "tan":view_item["tan"], "cut":cut, "cut_faces":view_item.get("cut_faces", []), "hatch_warnings":view_item.get("hatch_warnings", []), "cen_lines":view_item.get("cen_lines", []), "label":view_item["label"], "N":view_item["N"], "U":view_item["U"], "R":view_item["R"], "is_iso":view_item["is_iso"], "is_section":bool(view_item.get("is_section", False)), "xmin":xmin, "xmax":xmax, "ymin":ymin, "ymax":ymax, "width":xmax - xmin, "height":ymax - ymin, "show_hidden":this_show_hidden, "scale":view_scale}
        col_w = [0.0] * (max(cell[0] for cell in layout.values()) + 1)
        row_h = [0.0] * (max(cell[1] for cell in layout.values()) + 1)
        for name in source_items:
            c, r = layout[name]
            col_w[c] = max(col_w[c], source_items[name]["width"])
            row_h[r] = max(row_h[r], source_items[name]["height"])
        spacing = float(self.hyp["視圖間隔"])
        col_x = [0.0]
        for w in col_w[:-1]:   col_x.append(col_x[-1] + w + spacing)
        row_y = [0.0]
        for h in row_h[:-1]:    row_y.append(row_y[-1] + h + spacing)
        self.proj_offset = {}
        view_data = {}
        for target_name in view_order:
            item = source_items[target_name]
            c, r = layout[target_name]
            dx = col_x[c] + (col_w[c] - item["width"]) / 2 - item["xmin"]
            dy = row_y[r] + (row_h[r] - item["height"]) / 2 - item["ymin"]
            dxf_lines = []
            visible_layer = "0"
            for group_name, layer in (("hidden", "HID"), ("tan", "TAN"), ("visible", visible_layer)):
                if group_name == "hidden" and not item["show_hidden"]: continue
                self.drawer.draw_view_edges(item[group_name], dx, dy, layer, group_name, item["scale"])
                if group_name not in ("visible", "hidden"): continue
                for prim in item[group_name]:
                    if prim["type"] != "LINE": continue
                    dxf_lines.append({"p1":(prim["p1"][0] * item["scale"] + dx, prim["p1"][1] * item["scale"] + dy), "p2":(prim["p2"][0] * item["scale"] + dx, prim["p2"][1] * item["scale"] + dy), "source":group_name})
            if item["cut"]:
                self.drawer.draw_view_edges(item["cut"], dx, dy, "cutted_0", "visible", item["scale"])
                for prim in item["cut"]:
                    if prim["type"] != "LINE": continue
                    dxf_lines.append({"p1":(prim["p1"][0] * item["scale"] + dx, prim["p1"][1] * item["scale"] + dy), "p2":(prim["p2"][0] * item["scale"] + dx, prim["p2"][1] * item["scale"] + dy), "source":"cut"})
            cen_lines = []
            for cen_item in item["cen_lines"]:
                p1 = (cen_item["p1"][0] * item["scale"] + dx, cen_item["p1"][1] * item["scale"] + dy)
                p2 = (cen_item["p2"][0] * item["scale"] + dx, cen_item["p2"][1] * item["scale"] + dy)
                self.drawer.add_line(p1, p2, "AUTO_CEN")
                cen_lines.append({"p1":p1, "p2":p2})
            self.proj_offset[target_name] = np.array([dx, dy], dtype=float)
            view_data[target_name] = {"dx":dx, "dy":dy, "xmin":item["xmin"] + dx, "xmax":item["xmax"] + dx, "ymin":item["ymin"] + dy, "ymax":item["ymax"] + dy, "width":item["width"], "height":item["height"], "label":item["label"], "N":item["N"], "U":item["U"], "R":item["R"], "is_iso":item["is_iso"], "is_section":item["is_section"], "show_hidden":item["show_hidden"], "cut_faces":item["cut_faces"], "hatch_warnings":item["hatch_warnings"], "cen_lines":cen_lines, "dxf_lines":dxf_lines, "col":c, "row":r,}
        self.view_data = view_data
        self.section_view_data = {name:view_data[name] for name in section_views}
        return self.doc
    def _cal_auto_notation_scale(self,):
        if self.view_data is None:
            raise ValueError("view_data is None, call layout_views first")
        front_name = "front"
        hor_name = next((view_name for view_name in self.autodim_views if view_name in ("right", "left")), "right")
        ver_name = next((view_name for view_name in self.autodim_views if view_name in ("top", "bottom")), "top")
        for view_name in (front_name, hor_name, ver_name):
            if view_name not in self.view_data:
                raise ValueError(f"view not found: {view_name}")
        front_view = self.view_data[front_name]
        hor_view = self.view_data[hor_name]
        ver_view = self.view_data[ver_name]
        used_w = front_view["width"] * self.hyp["佔領圖紙權重"]["w"] + hor_view["width"]
        used_h = front_view["height"] * self.hyp["佔領圖紙權重"]["h"] + ver_view["height"]
        section_names = [name for name, item in self.view_data.items() if item.get("is_section")]
        if section_names:
            used_w = max(used_w, max(item["xmax"] for item in self.view_data.values()) - min(item["xmin"] for item in self.view_data.values()))
            used_h = max(used_h, max(item["ymax"] for item in self.view_data.values()) - min(item["ymin"] for item in self.view_data.values()))
        paper_w, paper_h = tuple(self.hyp["A3圖紙可用空間"])
        ok_scale = None
        ok_scale_name = None
        for this_scale_name in self.hyp["繪圖比例選項"]:
            nums = get_nums(str(this_scale_name))
            if len(nums) == 1:
                this_scale = nums[0]
            elif len(nums) >= 2 and nums[1] != 0:
                this_scale = nums[0] / nums[1]
            else:
                continue
            if used_w * this_scale <= paper_w and used_h * this_scale <= paper_h:
                ok_scale = this_scale
                ok_scale_name = this_scale_name
        if ok_scale is None:
            first_scale_name = self.hyp["繪圖比例選項"][0]
            nums = get_nums(str(first_scale_name))
            ok_scale = nums[0] / nums[1] if len(nums) >= 2 and nums[1] != 0 else nums[0]
            ok_scale_name = first_scale_name
        self.notation_scale = ok_scale
        self.notation_scale_name = ok_scale_name
        return {"notation_scale":ok_scale, "notation_scale_name":ok_scale_name, "used_w":used_w, "used_h":used_h, "paper_w":paper_w, "paper_h":paper_h, "view_names":(front_name, hor_name, ver_name, *section_names)}

    #  ---------------  標題欄與素材尺寸  ----------------
    def _cal_size_items(self, tol=0.05):
        bb = self.translater.model.val().BoundingBox()
        dims = sorted([float(bb.xlen), float(bb.ylen), float(bb.zlen)], reverse=True)
        for fid in self.info["faces"]:
            face = self.info["faces"][fid]
            if face["func"] != "CYLINDRICAL_SURFACE" or face.get("body") != "outside": continue
            dia = float(face["r"]) * 2
            match = [d for d in dims if abs(d - dia) <= max(tol, dia * 1e-3)]
            if len(match) < 2: continue
            length = next((d for d in dims if abs(d - dia) > max(tol, dia * 1e-3)), dia)
            return {"round": True, "vals": [dia, length]}
        return {"round": False, "vals": dims}
    def _fmt_size(self, size_items):
        vals = [f"{round(v, 2):g}" for v in size_items["vals"]]
        if size_items["round"]: return f"%%c{vals[0]}X{vals[1]}"
        return "X".join(vals)
    def _stock_size(self, size_items, round_digits=2):
        stock_vals = []
        for v in size_items["vals"]:
            s = math.ceil(round(v, round_digits) + 2)
            if s % 2: s += 1
            stock_vals.append(s)
        return {"round": size_items["round"], "vals": stock_vals}
    def add_title_info(self, layer="0", row=None, col=None, margin=None):
        if margin is None: margin = self.hyp["尺寸排起始間隔"]
        anchor_x = min(self.view_data[n]["xmin"] for n in self.view_data)
        anchor_y = min(self.view_data[n]["ymin"] for n in self.view_data) - margin
        size_items = self._cal_size_items()
        part_text = self._fmt_size(size_items)
        stock_text = self._fmt_size(self._stock_size(size_items))
        fname = os.path.basename(self.stp_fpath) if self.stp_fpath else ""
        today = datetime.date.today().isoformat()
        scale_name = getattr(self, "notation_scale_name", f"{self.notation_scale:g}")
        h = self.hyp["標準字體高度"] * 3
        lines = [fname, today, f"SCALE {scale_name}", f"PART {part_text}", f"STOCK {stock_text}"]
        if self.hyp["板金模式"]["啟用"] and getattr(self, "sheet_thickness", None) is not None: lines.append(f"THICKNESS t{self.sheet_thickness:g}")
        self.drawer.add_mtext("\\P".join(lines), (anchor_x, anchor_y), layer, text_h=h, attachment_point=1)
        return lines

    #  ---------------  特徵分派  ----------------
    def build_view_payloads(self,):
        payloads = {}
        for view_name in self.autodim_views:
            if view_name not in self.view_data: continue
            if self.view_data[view_name].get("is_iso"): continue
            payloads[view_name] = {"view_name":view_name, "origin":None, "holes":[], "threads":[], "fillets":[], "chamfers":[], "ribs":[], "rib_aux_lines":[], "cyns":[], "planes":[], "centerlines":[], "cen_lines":[]}
        self._dispatch_holes(payloads)
        self._dispatch_threads(payloads)
        self._dispatch_fillets(payloads)
        self._dispatch_chamfers(payloads)
        self._dispatch_ribs(payloads)
        self._dispatch_cyns(payloads)
        self._dispatch_planes(payloads)
        self._filter_sheetmetal_planes(payloads)
        self._dispatch_centerlines(payloads)
        self._dispatch_slot_centerlines(payloads)
        self._dispatch_arc_centerlines(payloads)
        self._merge_centerlines(payloads)
        self._dispatch_locations(payloads)
        self.view_payloads = payloads
        return payloads
    def _dispatch_ribs(self, payloads):
        for item in self.info.get("rib_dims", []):
            if item.get("kind") != "rib": continue
            dim_pts = item.get("dim_pts")
            if not dim_pts: continue
            axis_vec = [0.0, 0.0, 0.0]
            axis_vec[item["free_axis"]] = 1.0
            pick = None
            for view_name in payloads:
                if self.projector.dir_in_view(axis_vec, view_name) is not None:
                    pick = view_name
                    break
            if pick is None: continue
            pts_2d = self._proj_2_view(dim_pts, pick)
            for p in pts_2d:
                payloads[pick]["ribs"].append({"xy":(float(p[0]), float(p[1]))})
        return payloads
    def _dispatch_chamfers(self, payloads):
        pull = self.hyp["標準字體高度"] / self.notation_scale * 4
        for item in self.info.get("rib_dims", []):
            if item.get("kind") != "chamfer": continue
            n = item.get("dir_n")
            verts = item.get("verts")
            w = item.get("w")
            if n is None or not verts or w is None: continue
            d = self.rotation_matrix @ np.array(n, dtype=float)
            pick = None
            for view_name in payloads:
                view_n = np.array(VIEW_DIRECTION[view_name]["N"], dtype=float)
                view_n = view_n / np.linalg.norm(view_n)
                if abs(float(np.dot(d, view_n))) > 1e-2: continue
                pick = view_name
                break
            if pick is None: continue
            pts_2d = self._proj_2_view(verts, pick)
            best = (0, 1)
            best_len = -1.0
            for a in range(len(pts_2d)):
                for b in range(a + 1, len(pts_2d)):
                    seg = float(np.linalg.norm(pts_2d[a] - pts_2d[b]))
                    if seg > best_len: best_len, best = seg, (a, b)
            p1 = pts_2d[best[0]]
            p2 = pts_2d[best[1]]
            anchor = ((float(p1[0]) + float(p2[0])) / 2, (float(p1[1]) + float(p2[1])) / 2)
            nd = self.projector.proj_pt(n, pick)[0]
            nd = np.array([float(nd[0]), float(nd[1])], dtype=float)
            nd_len = float(np.linalg.norm(nd))
            if nd_len < 1e-9: continue
            nd = nd / nd_len
            vd = self.view_data[pick]
            cx = (vd["xmin"] + vd["xmax"]) / 2
            cy = (vd["ymin"] + vd["ymax"]) / 2
            if nd[0] * (anchor[0] - cx) + nd[1] * (anchor[1] - cy) < 0: nd = -nd
            ts = []
            if abs(nd[0]) > 1e-9: ts.append(((vd["xmax"] if nd[0] > 0 else vd["xmin"]) - anchor[0]) / nd[0])
            if abs(nd[1]) > 1e-9: ts.append(((vd["ymax"] if nd[1] > 0 else vd["ymin"]) - anchor[1]) / nd[1])
            t_exit = min([t for t in ts if t > 0], default=0.0)
            tip = (anchor[0] + nd[0] * (t_exit + pull), anchor[1] + nd[1] * (t_exit + pull))
            payloads[pick]["chamfers"].append({"w":w, "anchor":anchor, "tip":tip})
        return payloads
    def _dispatch_holes(self, payloads):
        view_circles = {}
        for view_name in payloads:
            view_circles[view_name] = self._cal_view_circles(view_name)
        for item in self.info.get("hole_dims", []):
            dir_n = item.get("dir_n")
            org = item.get("org")
            if dir_n is None or org is None: continue
            d = -(self.rotation_matrix @ np.array(dir_n, dtype=float))
            pick = None
            back = False
            for view_name in payloads:
                collinear = cal_collinear(d, VIEW_DIRECTION[view_name]["N"])
                if collinear == "negative":
                    pick, back = view_name, False
                    break
                if collinear == "postive":
                    pick, back = view_name, True
                    break
            if pick is None: continue
            xy = self._proj_2_view(org, pick)[0]
            xy = (float(xy[0]), float(xy[1]))
            circles = view_circles[pick]
            hit_back = self._cal_circle_back(circles, xy)
            if hit_back is not None: back = hit_back
            cbore_back = back
            cbore_d = item.get("cbore_d")
            if item.get("is_cbore") and cbore_d is not None:
                hit_cbore_back = self._cal_circle_back(circles, xy, r=float(cbore_d) / 2)
                if hit_cbore_back is not None: cbore_back = hit_cbore_back
            payloads[pick]["holes"].append({"xy":xy, "text_top":item.get("text_top", ""), "text_bottom":item.get("text_bottom", ""), "back":back, "cbore_back":cbore_back, "org":org})
        return payloads
    def _dispatch_threads(self, payloads):
        for item in self.info.get("thread_features", []):
            dir_n = item.get("dir_n")
            org = item.get("org")
            if dir_n is None or org is None: continue
            for view_name in payloads:
                collinear = self.projector.dir_in_view(dir_n, view_name)
                center = self._proj_2_view(org, view_name)[0]
                major_r = float(item["major_d"]) / 2
                minor_r = float(item["minor_d"]) / 2
                if collinear is not None:
                    facing = "front" if (collinear == "postive" or item.get("is_through")) else "back"
                    payloads[view_name]["threads"].append({"facing":facing, "center":(float(center[0]), float(center[1])), "p1":None, "p2":None, "major_r":major_r, "minor_r":minor_r, "is_through":item.get("is_through")})
                    continue
                pts_2d = self._proj_2_view([item["start_pt"], item["end_pt"]], view_name)
                p1 = pts_2d[0]
                p2 = pts_2d[1]
                if float(np.linalg.norm(p2 - p1)) < 1e-6: continue
                payloads[view_name]["threads"].append({"facing":"side", "center":(float(center[0]), float(center[1])), "p1":(float(p1[0]), float(p1[1])), "p2":(float(p2[0]), float(p2[1])), "major_r":major_r, "is_through":item.get("is_through")})
        return payloads
    def _dispatch_fillets(self, payloads):
        for item in self.info.get("fillet_dims", []):
            org = item.get("org")
            dir_n = item.get("dir_n")
            arc_dir = item.get("arc_dir")
            r = item.get("r")
            if org is None or dir_n is None or arc_dir is None or r is None: continue
            pick = None
            for view_name in payloads:
                if self.projector.dir_in_view(dir_n, view_name) is not None:
                    pick = view_name
                    break
            if pick is None: continue
            center = self._proj_2_view(org, pick)[0]
            p1_3d = (np.array(org, dtype=float) + np.array(arc_dir, dtype=float) * float(r)).tolist()
            p1 = self._proj_2_view(p1_3d, pick)[0]
            if abs(float(p1[0] - center[0])) <= self.geom_match_tol or abs(float(p1[1] - center[1])) <= self.geom_match_tol:
                view_item = self.projector.get_view(pick)
                dx, dy = self.proj_offset[pick]
                arc_items = []
                for group_name in ("visible", "hidden"):
                    for arc_item in view_item[group_name]:
                        if arc_item["type"] not in ("ARC", "CIRCLE"): continue
                        if abs(float(arc_item["c"][0] + dx - center[0])) > self.geom_match_tol: continue
                        if abs(float(arc_item["c"][1] + dy - center[1])) > self.geom_match_tol: continue
                        if abs(float(arc_item["r"] - r)) > self.geom_match_tol: continue
                        arc_items.append(arc_item)
                this_angle = math.degrees(math.atan2(float(p1[1] - center[1]), float(p1[0] - center[0]))) % 360.0
                angles = [ang for ang in (45.0, 135.0, 225.0, 315.0) if any(arc_item["type"] == "CIRCLE" or self.projector._arc_has_angle(arc_item["a1"], arc_item["a2"], ang) for arc_item in arc_items)]
                if angles:
                    this_angle = min(angles, key=lambda ang: abs((ang - this_angle + 180.0) % 360.0 - 180.0))
                elif arc_items:
                    arc_item = max(arc_items, key=lambda item: 360.0 if item["type"] == "CIRCLE" else self.projector._arc_span(item["a1"], item["a2"]))
                    if arc_item["type"] == "CIRCLE": this_angle = 45.0
                    else:
                        span = self.projector._arc_span(arc_item["a1"], arc_item["a2"])
                        this_angle = (float(arc_item["a1"]) + span / 2) % 360.0
                        if abs(math.sin(math.radians(this_angle * 2))) <= 1e-6: this_angle = (this_angle + min(5.0, span / 4)) % 360.0
                else: this_angle = (this_angle + 45.0) % 360.0
                p1 = np.array([float(center[0]) + float(r) * math.cos(math.radians(this_angle)), float(center[1]) + float(r) * math.sin(math.radians(this_angle))])
            payloads[pick]["fillets"].append({"center":(float(center[0]), float(center[1])), "p1":(float(p1[0]), float(p1[1])), "r":float(r)})
        return payloads
    def _dispatch_cyns(self, payloads):
        for item in self.info.get("cyn_dims", []):
            org = item.get("org")
            dir_n = item.get("dir_n")
            r = item.get("r")
            if org is None or dir_n is None or r is None: continue
            pick = None
            for view_name in payloads:
                if self.projector.dir_in_view(dir_n, view_name) is not None:
                    pick = view_name
                    break
            if pick is None: continue
            center = self._proj_2_view(org, pick)[0]
            payloads[pick]["cyns"].append({"center":(float(center[0]), float(center[1])), "r":float(r)})
        return payloads
    def _dispatch_planes(self, payloads):
        for item in self.info.get("plane_dims", []):
            org = item.get("org")
            dir_n = item.get("dir_n")
            if org is None or dir_n is None: continue
            d = self.rotation_matrix @ np.array(dir_n, dtype=float)
            pick = None
            orientation = None
            for view_name in payloads:
                view_item = VIEW_DIRECTION[view_name]
                view_n = np.array(view_item["N"], dtype=float)
                view_u = np.array(view_item["U"], dtype=float)
                view_r = np.cross(view_u, view_n)
                view_r = view_r / np.linalg.norm(view_r)
                view_u = view_u / np.linalg.norm(view_u)
                if cal_collinear(d, view_n) is not None: continue
                collinear_r = cal_collinear(d, view_r)
                collinear_u = cal_collinear(d, view_u)
                if collinear_r is None and collinear_u is None: continue
                pick = view_name
                orientation = "X" if collinear_r is not None else "Y"
                break
            if pick is None: continue
            xy = self._proj_2_view(org, pick)[0]
            payloads[pick]["planes"].append({"orientation":orientation, "pos_2d":(float(xy[0]), float(xy[1])), "face_id":item["id"]})
        return payloads
    def _resolve_sheet_thickness(self, payloads):
        cfg = self.hyp["板金模式"]
        spacings = []
        for view_name in payloads:
            for orientation in ("X", "Y"):
                pos = sorted(set(round(item["pos_2d"][0] if orientation == "X" else item["pos_2d"][1], 2) for item in payloads[view_name]["planes"] if item["orientation"] == orientation))
                spacings += [round(b - a, 2) for a, b in zip(pos, pos[1:])]
        detected = max(set(spacings), key=spacings.count) if spacings else None
        declared = cfg.get("板厚")
        if declared is None:
            if detected is not None: print(f"[板金] 自動偵測板厚 = {detected}")
            return detected
        if detected is not None and abs(float(declared) - float(detected)) > float(cfg["厚度容差"]): print(f"[板金] 警告: 指定板厚 {declared} 與偵測眾數 {detected} 不符")
        return float(declared)
    def _filter_sheetmetal_planes(self, payloads):
        self.sheet_thickness = None
        if not self.hyp["板金模式"]["啟用"]: return payloads
        t = self._resolve_sheet_thickness(payloads)
        self.sheet_thickness = t
        if t is None: return payloads
        tol_t = float(self.hyp["板金模式"]["厚度容差"])
        for view_name in payloads:
            items = payloads[view_name]["planes"]
            keep = [True] * len(items)
            for orientation in ("X", "Y"):
                idx_items = [(k, items[k]["pos_2d"][0] if orientation == "X" else items[k]["pos_2d"][1]) for k in range(len(items)) if items[k]["orientation"] == orientation]
                idx_items.sort(key=lambda x: x[1])
                if not idx_items: continue
                mid = (idx_items[0][1] + idx_items[-1][1]) / 2
                k = 0
                while k < len(idx_items) - 1:
                    ia, pa = idx_items[k]
                    ib, pb = idx_items[k + 1]
                    if abs((pb - pa) - t) <= tol_t:
                        inner_idx = ia if abs(pa - mid) < abs(pb - mid) else ib
                        keep[inner_idx] = False
                        print(f"[板金] 抑制內側面 {items[inner_idx]['face_id']} @ {view_name} {orientation}")
                        k += 2
                    else: k += 1
            payloads[view_name]["planes"] = [items[k] for k in range(len(items)) if keep[k]]
        return payloads
    def _dispatch_slot_centerlines(self, payloads):
        self._slot_arc_excl = {}
        if not self.hyp["滑槽偵測"]["啟用"]: return payloads
        for item in self.info.get("slot_dims", []):
            pick = None
            for view_name in payloads:
                if self.projector.dir_in_view(item["dir_axis"], view_name) is not None:
                    pick = view_name
                    break
            if pick is None: continue
            r = float(item["r"])
            pts_2d = self._proj_2_view([item["org1"], item["org2"]], pick)
            q1 = np.array([float(pts_2d[0][0]), float(pts_2d[0][1])], dtype=float)
            q2 = np.array([float(pts_2d[1][0]), float(pts_2d[1][1])], dtype=float)
            v = q2 - q1
            v_len = float(np.linalg.norm(v))
            if v_len < 1e-6: continue
            v = v / v_len
            w = np.array([-v[1], v[0]], dtype=float)
            p1 = q1 - v * r
            p2 = q2 + v * r
            payloads[pick]["centerlines"].append({"cen_type":"十字", "p1":(float(p1[0]), float(p1[1])), "p2":(float(p2[0]), float(p2[1]))})
            for q in (q1, q2):
                t1 = q - w * r
                t2 = q + w * r
                payloads[pick]["centerlines"].append({"cen_type":"十字", "p1":(float(t1[0]), float(t1[1])), "p2":(float(t2[0]), float(t2[1]))})
            raw_2d = self.projector.proj_pt([item["org1"], item["org2"]], pick)
            if pick not in self._slot_arc_excl: self._slot_arc_excl[pick] = []
            self._slot_arc_excl[pick] += [(float(raw_2d[0][0]), float(raw_2d[0][1]), r), (float(raw_2d[1][0]), float(raw_2d[1][1]), r)]
        return payloads
    def _dispatch_centerlines(self, payloads):
        for item in self.info.get("centerline_raw_pts", []):
            if not isinstance(item, dict): continue
            p1 = item.get("p1")
            p2 = item.get("p2")
            cen_type = item.get("cen_type")
            dir_n = item.get("dir_n")
            if p1 is None or p2 is None: continue
            for view_name in payloads:
                if cen_type == "十字":
                    if dir_n is None: continue
                    if self.projector.dir_in_view(dir_n, view_name) is None: continue
                pts_2d = self._proj_2_view([p1, p2], view_name)
                q1 = pts_2d[0]
                q2 = pts_2d[1]
                if float(np.linalg.norm(q2 - q1)) < 1e-6: continue
                payloads[view_name]["centerlines"].append({"cen_type":cen_type, "p1":(float(q1[0]), float(q1[1])), "p2":(float(q2[0]), float(q2[1]))})
        return payloads
    def _dispatch_arc_centerlines(self, payloads):
        threshold = float(self.hyp["圓弧中心線角度門檻"])
        eta = 1e-6
        snap_tol = 1e-3
        for view_name in payloads:
            view_item = self.projector.get_view(view_name)
            dx, dy = self.proj_offset[view_name]
            axis_xs = []
            axis_ys = []
            for item in payloads[view_name]["centerlines"]:
                x1, y1 = item["p1"]
                x2, y2 = item["p2"]
                if abs(x1 - x2) < eta: axis_xs.append((x1 + x2) / 2)
                elif abs(y1 - y2) < eta: axis_ys.append((y1 + y2) / 2)
            arc_items = {}
            for group_name in ("visible", "hidden"):
                for item in view_item[group_name]:
                    if item["type"] != "ARC": continue
                    key = (round(float(item["c"][0]), 4), round(float(item["c"][1]), 4), round(float(item["r"]), 4))
                    if any(abs(key[0] - ex) <= self.geom_match_tol and abs(key[1] - ey) <= self.geom_match_tol and abs(key[2] - er) <= self.geom_match_tol for ex, ey, er in getattr(self, "_slot_arc_excl", {}).get(view_name, [])): continue
                    if key not in arc_items: arc_items[key] = {"span":0.0, "dirs":[False, False, False, False]}
                    arc_items[key]["span"] += self.projector._arc_span(item["a1"], item["a2"])
                    for i, ang in enumerate((0.0, 90.0, 180.0, 270.0)):
                        if self.projector._arc_has_angle(item["a1"], item["a2"], ang): arc_items[key]["dirs"][i] = True
            for key in arc_items:
                if arc_items[key]["span"] < threshold: continue
                cx = key[0] + float(dx)
                cy = key[1] + float(dy)
                r = key[2]
                for x in axis_xs:
                    if abs(x - cx) <= snap_tol:
                        cx = x
                        break
                for y in axis_ys:
                    if abs(y - cy) <= snap_tol:
                        cy = y
                        break
                axis_xs.append(cx)
                axis_ys.append(cy)
                dirs = arc_items[key]["dirs"]
                if dirs[0]: payloads[view_name]["centerlines"].append({"cen_type":"十字", "p1":(cx, cy), "p2":(cx + r, cy)})
                if dirs[2]: payloads[view_name]["centerlines"].append({"cen_type":"十字", "p1":(cx - r, cy), "p2":(cx, cy)})
                if dirs[1]: payloads[view_name]["centerlines"].append({"cen_type":"十字", "p1":(cx, cy), "p2":(cx, cy + r)})
                if dirs[3]: payloads[view_name]["centerlines"].append({"cen_type":"十字", "p1":(cx, cy), "p2":(cx, cy - r)})
        return payloads
    def _merge_centerlines(self, payloads, gap=None):
        eta = 1e-6
        round_digits = 6
        if gap is None: gap = 1 / self.notation_scale
        for view_name in payloads:
            vertical_items = {}
            horizontal_items = {}
            other_items = {}
            for item in payloads[view_name]["centerlines"]:
                x1, y1 = item["p1"]
                x2, y2 = item["p2"]
                dx = x2 - x1
                dy = y2 - y1
                if (dx * dx + dy * dy) ** 0.5 < eta: continue
                if abs(dx) < eta:
                    key = round((x1 + x2) / 2, round_digits)
                    if key not in vertical_items: vertical_items[key] = []
                    vertical_items[key] += [y1, y2]
                elif abs(dy) < eta:
                    key = round((y1 + y2) / 2, round_digits)
                    if key not in horizontal_items: horizontal_items[key] = []
                    horizontal_items[key] += [x1, x2]
                else:
                    key = tuple(sorted([(round(x1, round_digits), round(y1, round_digits)), (round(x2, round_digits), round(y2, round_digits))]))
                    if key in other_items: continue
                    other_items[key] = ((x1, y1), (x2, y2))
            cen_lines = []
            for x in vertical_items:
                ys = vertical_items[x]
                cen_lines.append({"p1":(x, min(ys) - gap), "p2":(x, max(ys) + gap)})
            for y in horizontal_items:
                xs = horizontal_items[y]
                cen_lines.append({"p1":(min(xs) - gap, y), "p2":(max(xs) + gap, y)})
            for key in other_items:
                p1, p2 = other_items[key]
                cen_lines.append({"p1":p1, "p2":p2})
            payloads[view_name]["cen_lines"] = cen_lines
        return payloads
    def _dispatch_locations(self, payloads, tol=None):
        if tol is None: tol = self.geom_match_tol
        for view_name in payloads:
            lines = []
            for item in self.view_data[view_name].get("dxf_lines", []):
                lines.append({"p1":item["p1"], "p2":item["p2"], "source":item["source"]})
            for item in payloads[view_name]["cen_lines"]:
                lines.append({"p1":item["p1"], "p2":item["p2"], "source":"cen"})
            pts = []
            outline_pts = []
            x_values = []
            y_values = []
            for item in lines:
                p1 = item["p1"]
                p2 = item["p2"]
                pts += [p1, p2]
                if item["source"] != "cen": outline_pts += [p1, p2]
                x_values += [p1[0], p2[0]]
                y_values += [p1[1], p2[1]]
                if abs(p2[0] - p1[0]) <= tol: x_values.append((p1[0] + p2[0]) / 2)
                if abs(p2[1] - p1[1]) <= tol: y_values.append((p1[1] + p2[1]) / 2)
            if not pts or not outline_pts:
                payloads[view_name]["location_data"] = {"x_items":{}, "y_items":{}}
                payloads[view_name]["origin"] = None
                continue
            x_groups = []
            for value in sorted(x_values):
                if not x_groups or value - x_groups[-1][0] > tol: x_groups.append([value])
                else: x_groups[-1].append(value)
            y_groups = []
            for value in sorted(y_values):
                if not y_groups or value - y_groups[-1][0] > tol: y_groups.append([value])
                else: y_groups[-1].append(value)
            x_items = {float(np.median(group)): {"segments_by_source":{"visible":[], "hidden":[], "cen":[]}, "points_by_source":{"visible":[], "hidden":[], "cen":[]}, "outline_lim":None, "cen_lim":None} for group in x_groups}
            y_items = {float(np.median(group)): {"segments_by_source":{"visible":[], "hidden":[], "cen":[]}, "points_by_source":{"visible":[], "hidden":[], "cen":[]}, "outline_lim":None, "cen_lim":None} for group in y_groups}
            for item in lines:
                p1, p2 = item["p1"], item["p2"]
                source = item["source"]
                for x, y in (p1, p2):
                    x_key = min(x_items, key=lambda key: abs(key - x))
                    if abs(x_key - x) <= tol: x_items[x_key]["points_by_source"][source].append((x, y))
                    y_key = min(y_items, key=lambda key: abs(key - y))
                    if abs(y_key - y) <= tol: y_items[y_key]["points_by_source"][source].append((x, y))
                if abs(p2[0] - p1[0]) <= tol:
                    line_x = (p1[0] + p2[0]) / 2
                    x_key = min(x_items, key=lambda key: abs(key - line_x))
                    if abs(x_key - line_x) <= tol: x_items[x_key]["segments_by_source"][source].append([min(p1[1], p2[1]), max(p1[1], p2[1])])
                if abs(p2[1] - p1[1]) <= tol:
                    line_y = (p1[1] + p2[1]) / 2
                    y_key = min(y_items, key=lambda key: abs(key - line_y))
                    if abs(y_key - line_y) <= tol: y_items[y_key]["segments_by_source"][source].append([min(p1[0], p2[0]), max(p1[0], p2[0])])
            for target_items, pt_idx in ((x_items, 1), (y_items, 0)):
                for item in target_items.values():
                    outline_segments = item["segments_by_source"]["visible"] + item["segments_by_source"]["hidden"]
                    outline_points = item["points_by_source"]["visible"] + item["points_by_source"]["hidden"]
                    if outline_segments: item["outline_lim"] = [min(seg[0] for seg in outline_segments), max(seg[1] for seg in outline_segments)]
                    elif outline_points: item["outline_lim"] = [min(point[pt_idx] for point in outline_points), max(point[pt_idx] for point in outline_points)]
                    cen_segments = item["segments_by_source"]["cen"]
                    cen_points = item["points_by_source"]["cen"]
                    if cen_segments: item["cen_lim"] = [min(seg[0] for seg in cen_segments), max(seg[1] for seg in cen_segments)]
                    elif cen_points: item["cen_lim"] = [min(point[pt_idx] for point in cen_points), max(point[pt_idx] for point in cen_points)]
            outline_x_items = [key for key, item in x_items.items() if item["outline_lim"] is not None]
            outline_y_items = [key for key, item in y_items.items() if item["outline_lim"] is not None]
            if not outline_x_items or not outline_y_items:
                payloads[view_name]["location_data"] = {"x_items":x_items, "y_items":y_items}
                payloads[view_name]["origin"] = None
                continue
            outline_xmin = min(point[0] for point in outline_pts)
            outline_xmax = max(point[0] for point in outline_pts)
            outline_ymin = min(point[1] for point in outline_pts)
            outline_ymax = max(point[1] for point in outline_pts)
            special_base = self.hyp["特殊標住基準參考"].get(view_name)
            if special_base is None:
                x_base, y_base = self._cal_notation_base(view_name).split("-")
                datum_x = min(outline_x_items) if x_base == "left" else max(outline_x_items)
                datum_y = min(outline_y_items) if y_base == "bottom" else max(outline_y_items)
            else:
                if not isinstance(special_base, (list, tuple)) or len(special_base) != 2: raise ValueError(f"special notation base must be None or (dx, dy): {view_name}")
                try: base_dx, base_dy = float(special_base[0]), float(special_base[1])
                except: raise ValueError(f"special notation base must contain numbers: {view_name}")
                if not math.isfinite(base_dx) or not math.isfinite(base_dy): raise ValueError(f"special notation base must be finite: {view_name}")
                autodim_x_items = []
                autodim_y_items = []
                for item in payloads[view_name]["planes"]:
                    orientation = item["orientation"]
                    raw_axis_pos = item["pos_2d"][0] if orientation == "X" else item["pos_2d"][1]
                    target_items = x_items if orientation == "X" else y_items
                    axis_pos = min(target_items, key=lambda key: abs(key - raw_axis_pos))
                    if abs(axis_pos - raw_axis_pos) > tol: continue
                    autodim_items = autodim_x_items if orientation == "X" else autodim_y_items
                    if not any(abs(axis_pos - pos) <= tol for pos in autodim_items): autodim_items.append(axis_pos)
                for item in payloads[view_name]["centerlines"]:
                    if item["cen_type"] != "十字": continue
                    x1, y1 = item["p1"]
                    x2, y2 = item["p2"]
                    if abs(x2 - x1) <= tol:
                        orientation = "X"
                        raw_axis_pos = (x1 + x2) / 2
                        target_items = x_items
                    elif abs(y2 - y1) <= tol:
                        orientation = "Y"
                        raw_axis_pos = (y1 + y2) / 2
                        target_items = y_items
                    else: continue
                    axis_pos = min(target_items, key=lambda key: abs(key - raw_axis_pos))
                    if abs(axis_pos - raw_axis_pos) > tol: continue
                    autodim_items = autodim_x_items if orientation == "X" else autodim_y_items
                    if not any(abs(axis_pos - pos) <= tol for pos in autodim_items): autodim_items.append(axis_pos)
                for item in payloads[view_name].get("ribs", []):
                    for raw_axis_pos, target_items, autodim_items in ((item["xy"][0], x_items, autodim_x_items), (item["xy"][1], y_items, autodim_y_items)):
                        axis_pos = min(target_items, key=lambda key: abs(key - raw_axis_pos))
                        if abs(axis_pos - raw_axis_pos) > tol: continue
                        if not any(abs(axis_pos - pos) <= tol for pos in autodim_items): autodim_items.append(axis_pos)
                view_bbox = self.view_data[view_name]
                target_x = float(view_bbox["xmin"]) + base_dx
                target_y = float(view_bbox["ymin"]) + base_dy
                datum_x = min(sorted(autodim_x_items or outline_x_items), key=lambda key: abs(key - target_x))
                datum_y = min(sorted(autodim_y_items or outline_y_items), key=lambda key: abs(key - target_y))
            payloads[view_name]["location_data"] = {"x_items":x_items, "y_items":y_items, "xmin":min(point[0] for point in pts), "xmax":max(point[0] for point in pts), "ymin":min(point[1] for point in pts), "ymax":max(point[1] for point in pts), "outline_width":outline_xmax - outline_xmin, "outline_height":outline_ymax - outline_ymin}
            payloads[view_name]["origin"] = (float(datum_x), float(datum_y))
        return payloads

    #  ---------------  繪圖封裝  ----------------
    def add_line(self, p1, p2, layer):
        return self.drawer.add_line(p1, p2, layer)
    def add_linear_dim(self, p1, p2, location, angle=0, layer="DIM", text=None):
        return self.drawer.add_linear_dim(p1, p2, location, angle=angle, layer=layer, text=text, text_h=self.hyp["標準字體高度"], arrow_h=self.hyp["標準箭頭大小"], dim_scale=1.0 / self.notation_scale)
    def add_radius_dim(self, center, p1, angle=45, layer="DIM", text=None):
        return self.drawer.add_radius_dim(center, p1, angle=angle, layer=layer, text=text, text_h=self.hyp["標準字體高度"], arrow_h=self.hyp["標準箭頭大小"], dim_scale=1.0 / self.notation_scale)
    def add_diameter_dim(self, center, p1, angle=45, layer="DIM"):
        return self.drawer.add_diameter_dim(center, p1, angle=angle, layer=layer, text_h=self.hyp["標準字體高度"], arrow_h=self.hyp["標準箭頭大小"], dim_scale=1.0 / self.notation_scale)
    def add_ordinate_dim(self, feature_location, leader_endpoint, orientation="X", origin=(0, 0), text=None, layer="DIM"):
        return self.drawer.add_ordinate_dim(feature_location, leader_endpoint, orientation=orientation, origin=origin, text=text, layer=layer, text_h=self.hyp["標準字體高度"], arrow_h=self.hyp["標準箭頭大小"], dim_scale=1.0 / self.notation_scale)
    def add_qleader(self, xy, txy, word1, word2, layer):
        return self.drawer.add_qleader(xy, txy, word1, word2, layer, text_h=self.hyp["標準字體高度"] / self.notation_scale, arrow_h=self.hyp["標準箭頭大小"] / self.notation_scale)

    #  ---------------  自動標註  ----------------
    def add_auto_centerlines(self,):
        payloads = self.view_payloads if self.view_payloads else self.build_view_payloads()
        count = 0
        for view_name in payloads:
            for item in payloads[view_name]["cen_lines"]:
                self.add_line(item["p1"], item["p2"], "AUTO_CEN")
                count += 1
        return count
    def add_auto_thread_features(self,):
        payloads = self.view_payloads if self.view_payloads else self.build_view_payloads()
        count = 0
        for view_name in payloads:
            circles = self._cal_view_circles(view_name)
            for item in payloads[view_name]["threads"]:
                center = item["center"]
                major_r = item["major_r"]
                facing = item["facing"]
                if facing in ("front", "back"):
                    is_back = self._cal_circle_back(circles, center, item["minor_r"], tol=1e-2)
                    if is_back is None: is_back = (facing == "back")
                    self.drawer.add_arc(center, major_r, self.hyp["螺紋孔繪製角度"]["start"], self.hyp["螺紋孔繪製角度"]["end"], "HID" if is_back else "DIM")
                    count += 1
                    continue
                p1 = np.array(item["p1"], dtype=float)
                p2 = np.array(item["p2"], dtype=float)
                v = p2 - p1
                v_len = float(np.linalg.norm(v))
                if v_len < 1e-6: continue
                offset = np.array([-v[1], v[0]], dtype=float) / v_len * major_r
                self.add_line(tuple(p1 + offset), tuple(p2 + offset), "HID")
                self.add_line(tuple(p1 - offset), tuple(p2 - offset), "HID")
                count += 2
                if not item.get("is_through"):
                    self.add_line(tuple(p2 + offset), tuple(p2 - offset), "HID")
                    count += 1
        return count
    def add_autodim_chamfers(self, layer="AUTO_DIM"):
        payloads = self.view_payloads if self.view_payloads else self.build_view_payloads()
        groups = {}
        for view_name in payloads:
            for item in payloads[view_name]["chamfers"]:
                key = (view_name, round(float(item["w"]), 3))
                groups.setdefault(key, []).append(item)
        count = 0
        for key in groups:
            items = groups[key]
            item = items[0]
            w_text = f"{round(item['w'], 3):g}"
            n = len(items)
            word1 = f"{n}-C{w_text}" if n > 1 else f"C{w_text}"
            print(word1)
            self.add_qleader(item["anchor"], item["tip"], word1, "", layer)
            count += 1
        return count
    def add_autodim_fillet(self, layer="AUTO_DIM", angle=45):
        payloads = self.view_payloads if self.view_payloads else self.build_view_payloads()
        groups = {}
        for view_name in payloads:
            for item in payloads[view_name]["fillets"]:
                center = item["center"]
                p1 = item["p1"]
                this_angle = math.degrees(math.atan2(float(p1[1] - center[1]), float(p1[0] - center[0])))
                key = (view_name, round(float(item["r"]), 3))
                groups.setdefault(key, []).append({"center":center, "p1":p1, "angle":this_angle, "r":float(item["r"])})
        count = 0
        for key in groups:
            items = groups[key]
            item = items[0]
            r_text = f"{round(item['r'], 3):g}"
            text = f"{len(items)}-R{r_text}" if len(items) > 1 else f"R{r_text}"
            self.add_radius_dim(tuple(item["center"]), tuple(item["p1"]), angle=item["angle"], layer=layer, text=text)
            count += 1
        return count
    def add_autodim_cyn(self, layer="AUTO_DIM", angle=45):
        payloads = self.view_payloads if self.view_payloads else self.build_view_payloads()
        groups = {}
        for view_name in payloads:
            for item in payloads[view_name]["cyns"]:
                center = item["center"]
                key = (view_name, round(float(center[0]), 6), round(float(center[1]), 6))
                groups.setdefault(key, []).append({"center":center, "r":float(item["r"])})
        count = 0
        for key in groups:
            items = groups[key]
            if len(items) == 1:
                angles = [angle]
            else:
                pos_n = (len(items) + 1) // 2
                neg_n = len(items) // 2
                angles = [(i + 1) * 90 / (pos_n + 1) for i in range(pos_n)]
                angles += [-(i + 1) * 90 / (neg_n + 1) for i in range(neg_n)]
            for item, this_angle in zip(items, angles):
                center = item["center"]
                rad = math.radians(this_angle + 180)
                p1 = (center[0] + math.cos(rad) * item["r"], center[1] + math.sin(rad) * item["r"])
                self.add_diameter_dim(tuple(center), p1, angle=this_angle, layer=layer)
                count += 1
        return count
    def add_autodim_holes(self, layer="AUTO_DIM_HOLES", margin=None):
        if margin is None: margin = self.hyp["尺寸排起始間隔"]
        payloads = self.view_payloads if self.view_payloads else self.build_view_payloads()
        h = self.hyp["標準字體高度"] / self.notation_scale
        groups = {}
        view_keys = {}
        for view_name in payloads:
            for item in payloads[view_name]["holes"]:
                key = (view_name, item["back"], item["cbore_back"], item["text_top"], item["text_bottom"])
                groups.setdefault(key, []).append(item)
                view_keys.setdefault(view_name, [])
                if key not in view_keys[view_name]: view_keys[view_name].append(key)
        print("[DEBUG] hole_tag_mode =", self.hyp["孔編號模式開關"], "| views_with_holes =", list(view_keys.keys()))
        for view_name in view_keys:
            print("[DEBUG]", view_name, "types =", len(view_keys[view_name]), "counts =", [(k[3], len(groups[k])) for k in view_keys[view_name]])
        hole_tags = {}
        letters = "ABCDEFGHJKLMNPQRSTUVWXYZ"
        start_i = letters.index(self.hyp["孔編號起始字母"]) if self.hyp["孔編號起始字母"] in letters else 0
        if self.hyp["孔編號模式開關"] and "front" in view_keys:
            plural_keys = [k for k in view_keys["front"] if len(groups[k]) >= 2]
            if len(plural_keys) >= 2:
                sorted_keys = sorted(plural_keys, key=lambda k: (-groups[k][0]["xy"][1], groups[k][0]["xy"][0]))
                for i, key in enumerate(sorted_keys):
                    letter_i = start_i + i
                    if letter_i >= len(letters): break
                    hole_tags[key] = letters[letter_i]
        view_cols = {}
        for key in groups:
            view_name, back, cbore_back, text_top, text_bottom = key
            items = groups[key]
            n = len(items)
            tag = hole_tags.get(key)
            if tag is None:
                word1 = text_top if n == 1 else f"{n}-{text_top}"
                word2 = text_bottom if (text_bottom == "" or n == 1) else f"{n}-{text_bottom}"
            else:
                word1 = f"{tag}-{text_top}"
                word2 = text_bottom
                offset = h * self.hyp["孔標註排版"]["編號偏移"]
                for item in items:
                    self.drawer.add_mtext(tag, (item["xy"][0] + offset, item["xy"][1] + offset), layer, text_h=h, attachment_point=7)
            if back:
                if "," in word1:
                    word1, depth = word1.split(",", 1)
                    if depth in ["貫穿", "攻穿"]:
                        word1 = f"{word1},{depth}"
                    else:
                        word1 = f"{word1},背面{depth}"
                else:
                    word1 = f"{word1},背面"
            if cbore_back and word2 != "":
                if "," in word2:
                    word2, cbore_depth = word2.split(",", 1)
                    word2 = f"{word2},背面{cbore_depth}"
                else:
                    word2 = f"{word2},背面"
            xy = items[0]["xy"]
            vd = self.view_data[view_name]
            cx = (vd["xmin"] + vd["xmax"]) / 2
            side = "right" if xy[0] >= cx else "left"
            if view_name not in view_cols: view_cols[view_name] = {"left": [], "right": []}
            view_cols[view_name][side].append({"xy": xy, "word1": word1, "word2": word2})
        row_gap = h * self.hyp["孔標註排版"]["列間距"]
        count = 0
        for view_name in view_cols:
            vd = self.view_data[view_name]
            cy = (vd["ymin"] + vd["ymax"]) / 2
            for side in ("left", "right"):
                col = view_cols[view_name][side]
                if not col: continue
                col.sort(key=lambda e: -e["xy"][1])
                row_hs = [h * self.hyp["孔標註排版"]["單行列高"] if e["word2"] == "" else h * self.hyp["孔標註排版"]["雙行列高"] for e in col]
                total_h = sum(row_hs) + row_gap * (len(col) - 1)
                ty = cy + total_h / 2
                tx = vd["xmax"] + margin if side == "right" else vd["xmin"] - margin
                for e, rh in zip(col, row_hs):
                    self.add_qleader(e["xy"], (tx, ty - rh), e["word1"], e["word2"], layer)
                    ty -= rh + row_gap
                    count += 1
        return count
    def add_autodim_slots(self, layer="AUTO_DIM", margin=None):
        if margin is None: margin = self.hyp["尺寸排起始間隔"]
        if not self.hyp["滑槽偵測"]["啟用"]: return 0
        count = 0
        payloads = self.view_payloads if self.view_payloads else self.build_view_payloads()
        for item in self.info.get("slot_dims", []):
            pick = None
            for view_name in payloads:
                if self.projector.dir_in_view(item["dir_axis"], view_name) is not None:
                    pick = view_name
                    break
            if pick is None or pick not in self.view_data: continue
            pts_2d = self._proj_2_view([item["org1"], item["org2"]], pick)
            q1 = np.array([float(pts_2d[0][0]), float(pts_2d[0][1])], dtype=float)
            q2 = np.array([float(pts_2d[1][0]), float(pts_2d[1][1])], dtype=float)
            v = q2 - q1
            v_len = float(np.linalg.norm(v))
            if v_len < 1e-9: continue
            v = v / v_len
            w = np.array([-v[1], v[0]], dtype=float)
            r = float(item["width"]) / 2
            vd = self.view_data[pick]
            view_c = np.array([(vd["xmin"] + vd["xmax"]) / 2, (vd["ymin"] + vd["ymax"]) / 2], dtype=float)
            if float(np.linalg.norm(q2 - view_c)) >= float(np.linalg.norm(q1 - view_c)):
                e, ev = q2, v
            else:
                e, ev = q1, -v
            p1 = e - w * r
            p2 = e + w * r
            loc = e + ev * (r + float(margin))
            ang = 90 if abs(float(w[1])) >= abs(float(w[0])) else 0
            if item.get("is_through", True): word = "貫穿"
            elif item.get("depth") is not None: word = f"深{item['depth']}"
            else: word = "深?"
            self.add_linear_dim((float(p1[0]), float(p1[1])), (float(p2[0]), float(p2[1])), (float(loc[0]), float(loc[1])), angle=ang, layer=layer, text=f"<>,{word}")
            count += 1
        return count
    def add_autodim_locations(self, layer="AUTO_DIM", margin=None, round_digits=3):
        if margin is None: margin = self.hyp["尺寸排起始間隔"]
        tol = self.geom_match_tol
        linear_items = {}
        ordinate_items = {}
        count = 0
        payloads = self.view_payloads if self.view_payloads else self.build_view_payloads()
        for view_name in payloads:
            payload = payloads[view_name]
            origin = payload.get("origin")
            location_data = payload.get("location_data", {})
            x_items = location_data.get("x_items", {})
            y_items = location_data.get("y_items", {})
            if origin is None or not x_items or not y_items: continue
            x_base, y_base = self._cal_notation_base(view_name).split("-")
            plane_groups = []
            for item in payload["planes"]:
                orientation = item["orientation"]
                raw_axis_pos = item["pos_2d"][0] if orientation == "X" else item["pos_2d"][1]
                target_items = x_items if orientation == "X" else y_items
                axis_pos = min(target_items, key=lambda key: abs(key - raw_axis_pos))
                if abs(axis_pos - raw_axis_pos) > tol: continue
                value = abs(axis_pos - (origin[0] if orientation == "X" else origin[1]))
                group = next((group for group in plane_groups if group["orientation"] == orientation and abs(group["dimension_value"] - value) <= tol), None)
                if group is None:
                    group = {"orientation":orientation, "dimension_value":value, "plane_face_ids":[], "axis_positions":[]}
                    plane_groups.append(group)
                if item["face_id"] not in group["plane_face_ids"]: group["plane_face_ids"].append(item["face_id"])
                if not any(abs(axis_pos - pos) <= tol for pos in group["axis_positions"]): group["axis_positions"].append(axis_pos)
            candidates = []
            for group in plane_groups:
                if not group["axis_positions"]: continue
                if group["orientation"] == "X": axis_pos = min(group["axis_positions"]) if x_base == "left" else max(group["axis_positions"])
                else: axis_pos = min(group["axis_positions"]) if y_base == "bottom" else max(group["axis_positions"])
                candidates.append({"orientation":group["orientation"], "axis_pos":axis_pos, "dimension_value":group["dimension_value"], "plane_count":len(group["plane_face_ids"]), "axis_positions":group["axis_positions"]})
            for item in payload["centerlines"]:
                if item["cen_type"] != "十字": continue
                x1, y1 = item["p1"]
                x2, y2 = item["p2"]
                if abs(x2 - x1) <= tol:
                    orientation = "X"
                    raw_axis_pos = (x1 + x2) / 2
                    target_items = x_items
                elif abs(y2 - y1) <= tol:
                    orientation = "Y"
                    raw_axis_pos = (y1 + y2) / 2
                    target_items = y_items
                else: continue
                axis_pos = min(target_items, key=lambda key: abs(key - raw_axis_pos))
                if abs(axis_pos - raw_axis_pos) > tol: continue
                if any(candidate["orientation"] == orientation and any(abs(axis_pos - pos) <= tol for pos in candidate["axis_positions"]) for candidate in candidates): continue
                value = abs(axis_pos - (origin[0] if orientation == "X" else origin[1]))
                candidates.append({"orientation":orientation, "axis_pos":axis_pos, "dimension_value":value, "plane_count":0, "axis_positions":[axis_pos]})
            if self.hyp["板金模式"]["啟用"] and getattr(self, "sheet_thickness", None) is not None:
                candidates = [c for c in candidates if not (c["plane_count"] > 0 and abs(c["dimension_value"] - self.sheet_thickness) <= float(self.hyp["板金模式"]["厚度容差"]))]
            for candidate in sorted(candidates, key=lambda item: (item["orientation"], item["dimension_value"], item["axis_pos"])):
                orientation = candidate["orientation"]
                axis_pos = candidate["axis_pos"]
                target_items = x_items if orientation == "X" else y_items
                datum_pos = origin[0] if orientation == "X" else origin[1]
                datum_key = min(target_items, key=lambda key: abs(key - datum_pos))
                if abs(datum_key - datum_pos) > tol: continue
                datum_lim = target_items[datum_key]["outline_lim"] if target_items[datum_key]["outline_lim"] is not None else target_items[datum_key]["cen_lim"]
                target_lim = target_items[axis_pos]["outline_lim"] if candidate["plane_count"] > 0 else target_items[axis_pos]["cen_lim"]
                if datum_lim is None or target_lim is None: continue
                if orientation == "X":
                    alpha = self._cal_notation_alpha(view_name, "X")
                    span = location_data["ymax"] - location_data["ymin"]
                    is_span = span > tol and (target_lim[1] - target_lim[0]) >= span - max(tol, span * 1e-3)
                    if is_span:
                        side_name = "bottom" if alpha >= 0.5 else "top"
                    else:
                        feat = (target_lim[0] + target_lim[1]) / 2
                        pos_norm = (location_data["ymax"] - feat) / span if span > tol else 0.5
                        side_name = "bottom" if pos_norm < alpha else "top"
                    lim_idx = 0 if side_name == "bottom" else 1
                    p1 = (datum_key, datum_lim[lim_idx])
                    p2 = (axis_pos, target_lim[lim_idx])
                    leader_endpoint = (axis_pos, location_data["ymin"] - margin if side_name == "bottom" else location_data["ymax"] + margin)
                    view_len = location_data["outline_width"]
                else:
                    alpha = self._cal_notation_alpha(view_name, "Y")
                    span = location_data["xmax"] - location_data["xmin"]
                    is_span = span > tol and (target_lim[1] - target_lim[0]) >= span - max(tol, span * 1e-3)
                    if is_span:
                        side_name = "right" if alpha >= 0.5 else "left"
                    else:
                        feat = (target_lim[0] + target_lim[1]) / 2
                        pos_norm = (feat - location_data["xmin"]) / span if span > tol else 0.5
                        side_name = "right" if pos_norm >= alpha else "left"
                    lim_idx = 0 if side_name == "left" else 1
                    p1 = (datum_lim[lim_idx], datum_key)
                    p2 = (target_lim[lim_idx], axis_pos)
                    leader_endpoint = (location_data["xmin"] - margin if side_name == "left" else location_data["xmax"] + margin, axis_pos)
                    view_len = location_data["outline_height"]
                value = abs(axis_pos - datum_key)
                dim_len = abs(p2[0] - p1[0]) if orientation == "X" else abs(p2[1] - p1[1])
                outer_dim = abs(dim_len - view_len) <= max(tol, view_len * 1e-6)
                text = None
                if candidate["plane_count"] > 1:
                    if self.hyp["線性標注方法"].get(view_name, "linear") == "linear": text = f"{candidate['plane_count']}-<>"
                    else: text = f"{candidate['plane_count']}-{round(float(value), round_digits):g}"
                count += self._add_or_collect_autodim_item(linear_items, ordinate_items, view_name, orientation, side_name, value, p2, leader_endpoint, origin, p1=p1, p2=p2, pos=axis_pos, layer=layer, text=text, round_digits=round_digits, eta=tol, outer_dim=outer_dim)
            for item in payload.get("ribs", []):
                px, py = item["xy"]
                for orientation in ("X", "Y"):
                    pos = px if orientation == "X" else py
                    if any(c["orientation"] == orientation and any(abs(pos - p) <= tol for p in c["axis_positions"]) for c in candidates): continue
                    candidates.append({"orientation":orientation, "axis_pos":pos, "dimension_value":abs(pos - (origin[0] if orientation == "X" else origin[1])), "plane_count":0, "axis_positions":[pos]})
                    value = abs(pos - (origin[0] if orientation == "X" else origin[1]))
                    if orientation == "X":
                        alpha = self._cal_notation_alpha(view_name, "X")
                        span = location_data["ymax"] - location_data["ymin"]
                        pos_norm = (location_data["ymax"] - py) / span if span > tol else 0.5
                        side_name = "bottom" if pos_norm < alpha else "top"
                        leader_endpoint = (pos, location_data["ymin"] - margin if side_name == "bottom" else location_data["ymax"] + margin)
                    else:
                        alpha = self._cal_notation_alpha(view_name, "Y")
                        span = location_data["xmax"] - location_data["xmin"]
                        pos_norm = (px - location_data["xmin"]) / span if span > tol else 0.5
                        side_name = "right" if pos_norm >= alpha else "left"
                        leader_endpoint = (location_data["xmin"] - margin if side_name == "left" else location_data["xmax"] + margin, pos)
                    count += self._add_or_collect_autodim_item(linear_items, ordinate_items, view_name, orientation, side_name, value, (px, py), leader_endpoint, origin, layer=layer, round_digits=round_digits, eta=tol)
        count += self._flush_linear_autodim_items(linear_items, margin=margin, layer=layer)
        count += self._flush_ordinate_autodim_items(ordinate_items, layer=layer)
        return count
    def _add_or_collect_autodim_item(self, linear_items, ordinate_items, view_name, orientation, side_name, value, feature_location, leader_endpoint, origin, p1=None, p2=None, pos=None, layer="AUTO_DIM", text=None, round_digits=3, eta=1e-6, outer_dim=False):
        notation_method_default = self.hyp["線性標注方法"].get(view_name, "linear")
        if notation_method_default == "linear":
            if abs(value) < eta: return 0
            key = (view_name, orientation, side_name)
            if key not in linear_items: linear_items[key] = []
            if p1 is None or p2 is None:
                p1 = (origin[0], feature_location[1]) if orientation == "X" else (feature_location[0], origin[1])
                p2 = feature_location
            if pos is None:
                pos = feature_location[0] if orientation == "X" else feature_location[1]
            dim_len = abs(float(p2[0]) - float(p1[0])) if orientation == "X" else abs(float(p2[1]) - float(p1[1]))
            linear_items[key].append({"value":value, "dim_len":dim_len, "p1":p1, "p2":p2, "pos":pos, "text":text, "outer_dim":outer_dim})
            return 0
        key = (view_name, orientation, side_name)
        if key not in ordinate_items: ordinate_items[key] = []
        if pos is None: pos = feature_location[0] if orientation == "X" else feature_location[1]
        ordinate_items[key].append({"value":value, "feature_location":tuple(feature_location), "leader_endpoint":tuple(leader_endpoint), "origin":tuple(origin), "pos":pos, "text":text, "round_digits":round_digits})
        return 0
    def _flush_ordinate_autodim_items(self, ordinate_items, layer="AUTO_DIM"):
        min_gap = self.hyp["標準字體高度"] / self.notation_scale * self.hyp["座標標注推擠權重"]
        count = 0
        for key in ordinate_items:
            view_name, orientation, side_name = key
            x_base, y_base = self._cal_notation_base(view_name).split("-")
            near_base = x_base if orientation == "X" else y_base
            reverse = near_base in ("right", "up")
            items = sorted(ordinate_items[key], key=lambda item: item["pos"], reverse=reverse)
            last_pos = None
            for item in items:
                ideal = item["pos"]
                if last_pos is None:
                    place = ideal
                elif not reverse:
                    place = max(ideal, last_pos + min_gap)
                else:
                    place = min(ideal, last_pos - min_gap)
                last_pos = place
                feature_location = item["feature_location"]
                leader_endpoint = item["leader_endpoint"]
                if orientation == "X":
                    leader_endpoint = (place, leader_endpoint[1])
                else:
                    leader_endpoint = (leader_endpoint[0], place)
                text = item["text"]
                if text is None: text = f"{round(float(item['value']), item['round_digits']):g}"
                self.add_ordinate_dim(feature_location, leader_endpoint, orientation=orientation, origin=item["origin"], text=text, layer=layer)
                count += 1
        return count
    def _flush_linear_autodim_items(self, linear_items, margin=None, layer="AUTO_DIM"):
        if margin is None: margin = self.hyp["尺寸排起始間隔"]
        step = self.hyp["尺寸排間隔"] / self.notation_scale
        count = 0
        for key in linear_items:
            view_name, orientation, side_name = key
            vd = self.view_data[view_name]
            location_data = self.view_payloads.get(view_name, {}).get("location_data", {})
            xmin = location_data.get("xmin", vd["xmin"])
            xmax = location_data.get("xmax", vd["xmax"])
            ymin = location_data.get("ymin", vd["ymin"])
            ymax = location_data.get("ymax", vd["ymax"])
            items = sorted(linear_items[key], key=lambda x: (x.get("dim_len", x["value"]), x["pos"]))
            normal_items = [item for item in items if not item.get("outer_dim", False)]
            outer_items = [item for item in items if item.get("outer_dim", False)]
            if outer_items:
                if key not in self.linear_dim_outer_items: self.linear_dim_outer_items[key] = []
                self.linear_dim_outer_items[key] += outer_items
            self.linear_dim_normal_counts[key] = max(self.linear_dim_normal_counts.get(key, 0), len(normal_items))
            for idx, item in enumerate(normal_items):
                if orientation == "X":
                    location_y = ymin - margin - step * idx if side_name == "bottom" else ymax + margin + step * idx
                    self.add_linear_dim(tuple(item["p1"]), tuple(item["p2"]), (item["pos"], location_y), angle=0, layer=layer, text=item.get("text"))
                else:
                    location_x = xmin - margin - step * idx if side_name == "left" else xmax + margin + step * idx
                    self.add_linear_dim(tuple(item["p1"]), tuple(item["p2"]), (location_x, item["pos"]), angle=90, layer=layer, text=item.get("text"))
                count += 1
        count += self._flush_outer_linear_dim_items(margin=margin, layer=layer)
        return count
    def _flush_outer_linear_dim_items(self, margin=None, layer="AUTO_DIM"):
        if margin is None: margin = self.hyp["尺寸排起始間隔"]
        step = self.hyp["尺寸排間隔"] / self.notation_scale
        count = 0
        for key in list(self.linear_dim_outer_items.keys()):
            view_name, orientation, side_name = key
            if view_name not in self.view_data: continue
            vd = self.view_data[view_name]
            location_data = self.view_payloads.get(view_name, {}).get("location_data", {})
            xmin = location_data.get("xmin", vd["xmin"])
            xmax = location_data.get("xmax", vd["xmax"])
            ymin = location_data.get("ymin", vd["ymin"])
            ymax = location_data.get("ymax", vd["ymax"])
            items = sorted(self.linear_dim_outer_items[key], key=lambda x: (x.get("dim_len", x["value"]), x["pos"]))
            start_idx = self.linear_dim_normal_counts.get(key, 0)
            for add_idx, item in enumerate(items):
                idx = start_idx + add_idx
                if orientation == "X":
                    location_y = ymin - margin - step * idx if side_name == "bottom" else ymax + margin + step * idx
                    self.add_linear_dim(tuple(item["p1"]), tuple(item["p2"]), (item["pos"], location_y), angle=0, layer=layer, text=item.get("text"))
                else:
                    location_x = xmin - margin - step * idx if side_name == "left" else xmax + margin + step * idx
                    self.add_linear_dim(tuple(item["p1"]), tuple(item["p2"]), (location_x, item["pos"]), angle=90, layer=layer, text=item.get("text"))
                count += 1
            self.linear_dim_normal_counts[key] = start_idx + len(items)
        self.linear_dim_outer_items = {}
        return count

    #  ---------------  主流程與除錯  ----------------
    def run_main_process(self, show_hidden=None):
        self.drawer = DXF_Drawer()
        self.drawer.hyp = self.hyp
        self.doc = self.drawer.doc
        self.linear_dim_normal_counts = {}
        self.linear_dim_outer_items = {}
        if show_hidden is not None:
            for view_name in self.hyp["隱藏線可見"]:
                self.hyp["隱藏線可見"][view_name] = bool(show_hidden)
        self.layout_views()
        self._cal_auto_notation_scale()
        if self.section_view_data:
            hatch_cfg = self.hyp["剖面圖"]["填充線"]
            text_h = self.hyp["標準字體高度"] / self.notation_scale
            for section_view_data in self.section_view_data.values():
                hatch_report = {"count":0, "skipped":[]}
                if hatch_cfg["啟用"]:
                    hatch_report = self.drawer.add_hatch_faces(section_view_data.get("cut_faces", []), section_view_data["dx"], section_view_data["dy"], layer=hatch_cfg["圖層"], pattern_name=hatch_cfg["樣式"], angle=hatch_cfg["角度"], scale=float(hatch_cfg["比例"]) / self.notation_scale, min_area=hatch_cfg["最小面積"])
                hatch_report["skipped"] = list(section_view_data.get("hatch_warnings", [])) + hatch_report["skipped"]
                section_view_data["hatch_report"] = hatch_report
                for warning in hatch_report["skipped"]: print(f"[剖面填充] {warning}")
                text_x = (section_view_data["xmin"] + section_view_data["xmax"]) / 2
                text_y = section_view_data["ymin"] - text_h
                self.drawer.add_mtext(section_view_data["label"], (text_x, text_y), "0", text_h=text_h, attachment_point=2)
        self.build_view_payloads()
        self.add_auto_thread_features()
        self.add_autodim_fillet()
        self.add_autodim_chamfers()
        self.add_autodim_cyn()
        self.add_autodim_holes()
        self.add_autodim_slots()
        self.add_auto_centerlines()
        self.add_autodim_locations()
        self.add_title_info()
        self.drawer.apply_redraw_order()
        return self.doc
    def debug_print_payloads(self,):
        for view_name in self.view_payloads:
            payload = self.view_payloads[view_name]
            print("View", view_name, "origin =", payload["origin"])
            for group_name in ("holes", "threads", "fillets", "cyns", "planes", "centerlines"):
                print("   ", group_name, "=", len(payload[group_name]))
                for item in payload[group_name][:5]:
                    print("      ", item)
