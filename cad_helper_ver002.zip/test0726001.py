import sys
import os
import time
import threading
sys.path.append('toolbox')
from common_functions import *
from cad_helper import STEP_Translater, View_Projector, DXF_Drawer, CAD_Helper



fpath = "./stp_files/part3b.stp"
# stp_trans = STEP_Translater(fpath)
# stp_trans.debug_print_hole_dims()
# print(stp_trans.info["hole_dims"])
output_dxf_fpath = f"./output/{get_timestemp()}.dxf"
output_img_fpath = f"./output/{get_timestemp()}.png"
cad = CAD_Helper()
cad.load(fpath)
iso_scale = 0.8
cad.hyp["等角圖縮放"] = iso_scale
# cad.hyp["特殊標住基準參考"]["front"] = (18,20)
cad.hyp["特殊標住基準參考"]["right"] = (8,5)
cad.set_section_view("horizontal", 25, "top")
cad.set_section_view("horizontal", 20, "top", )
cad.set_section_view("horizontal", 15, "top")
cad.set_section_view("horizontal", 10, "top")
cad.set_section_view("vertical", 5.0001, "right")
cad.rotate(x=1)
# cad.rotate(x=2)
cad.run_main_process()
print("等角圖縮放", iso_scale, "iso_front", (cad.view_data["iso_front"]["width"], cad.view_data["iso_front"]["height"]), "iso_back", (cad.view_data["iso_back"]["width"], cad.view_data["iso_back"]["height"]))
drawer = DXF_Drawer()
drawer.add_dxf(cad, position=(0, 0))
drawer.save(output_dxf_fpath)
img = drawer.get_quick_view_img(text_scale=0.5)
save_img(output_img_fpath, img)
open_folder(output_dxf_fpath)
# open_folder(output_img_fpath)
# cv2.waitKey(0)
